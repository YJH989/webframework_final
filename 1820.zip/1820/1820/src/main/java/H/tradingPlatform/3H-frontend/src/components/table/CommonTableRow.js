import React from 'react';
import { Link ,useNavigate } from 'react-router-dom';

const CommonTableRow = ({ children,event }) => {

  const navigate = useNavigate();
  const goRouteId = (postId) => {
   navigate(`/talent/detail/${postId}`);
   console.log("클릭됨")
  }  
  return (
    <tr onClick={()=>{goRouteId(event)}} className="common-table-row">
      {
        children
      }
    </tr>
  )
}

export default CommonTableRow;