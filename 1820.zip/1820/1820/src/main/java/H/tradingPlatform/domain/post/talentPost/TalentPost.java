package H.tradingPlatform.domain.post.talentPost;
import H.tradingPlatform.domain.DateTime;
import H.tradingPlatform.domain.image.Image;
import H.tradingPlatform.domain.member.JoinMembers;
import H.tradingPlatform.domain.member.Member;
import H.tradingPlatform.domain.post.Post;
import H.tradingPlatform.domain.post.RecruitmentStatus;
import H.tradingPlatform.domain.post.category.CategoryDetail;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Entity
@DiscriminatorValue("TalentPost")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TalentPost extends Post {

    private int price;

    private Long recommendations;

    private String errandAddress;

    @Enumerated(value = EnumType.STRING)//진행 상태(모집 중, 진행 중, 완료)
    private RecruitmentStatus recruitmentStatus;

    private boolean emergency;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_detail_id")
    private CategoryDetail categoryDetail;

    //완료 시간
    private String completionTime;

    private int maxPersonNum;

    public void setCategoryDetail(CategoryDetail categoryDetail){
        this.categoryDetail = categoryDetail;
    }

    public TalentPost(String title, String content, Member member, int price, String errandAddress, boolean emergency, CategoryDetail categoryDetail, String completionTime, int maxPersonNum) {
        super(title, content, member);
        this.price = price;
        this.recommendations = 0L;
        this.errandAddress = errandAddress;
        this.recruitmentStatus = RecruitmentStatus.RECRUITING;
        this.emergency = emergency;
        setCategoryDetail(categoryDetail);
        this.completionTime = completionTime;
        this.maxPersonNum = maxPersonNum;
    }

    public void recommendationPlus(){
        this.recommendations += 1;
    }

    public void changeStatus(){
        this.recruitmentStatus = RecruitmentStatus.COMPLETION;
    }

    public void editPost(String completionTime, boolean emergency,
                         String errandAddress, int maxPersonNum, int price){
        this.completionTime = completionTime;
        this.emergency = emergency;
        this.errandAddress = errandAddress;
        this.maxPersonNum = maxPersonNum;
        this.price = price;
    }
}
