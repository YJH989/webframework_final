package H.tradingPlatform.domain.post.talentPost.controller;

import H.tradingPlatform.ResponseResult;
import H.tradingPlatform.domain.post.talentPost.dto.PostTalentPostRequestDto;
import H.tradingPlatform.domain.post.talentPost.service.TalentPostService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletRequest;
import javax.validation.Valid;
import java.io.File;
import java.io.IOException;

@RequiredArgsConstructor
@RestController
public class TalentPostController {

    private final TalentPostService talentPostService;
    @Value("${file.dir}")
    private String fileDir;

    @GetMapping("/talents")
    public ResponseResult talentsList
            (@RequestParam("offset") int offset, @RequestParam("limit")int limit){

        return talentPostService.findTalentPosts(offset,limit);
    }

    @GetMapping("/talent/detail")
    public ResponseResult talentPostDetail(ServletRequest request, @RequestParam("postId")Long postId){

        return talentPostService.findTalentPostDetail(request, postId);
    }

    @PostMapping("/talent/join")
    public ResponseResult talentPostJoin(ServletRequest request,@RequestParam("postId")Long postId){

        return talentPostService.addJoinMember(request, postId);
    }

    @PostMapping("/talent/post")
    public ResponseResult postTalentPost(ServletRequest request, @RequestPart MultipartFile file,
                                         @RequestParam String title, @RequestParam String content,
                                         @RequestParam String completionTime,@RequestParam boolean emergency,
                                         @RequestParam String errandAddress,@RequestParam int maxPersonNum,
                                         @RequestParam int price, @RequestParam Long categoryDetailId) throws IOException {

        String fullPath = null;
        if (!file.isEmpty()) {
            fullPath = fileDir + file.getOriginalFilename();
            file.transferTo(new File(fullPath));
        }

        return talentPostService.post(request, fullPath, title, content, completionTime, emergency, errandAddress,
                maxPersonNum, price, categoryDetailId);
    }

    @PostMapping("/talent/views")
    public ResponseResult talentPostView(ServletRequest request,@RequestParam("postId")Long postId){

        return talentPostService.viewPlus(request, postId);
    }

    @PostMapping("/talent/reco")
    public ResponseResult talentPostRecommendation(ServletRequest request,@RequestParam("postId")Long postId){

        return talentPostService.recommendPlus(request, postId);
    }

    @PostMapping("/talent/complete")
    public ResponseResult talentPostComplete(@RequestParam("postId")Long postId){

        return talentPostService.complete(postId);
    }

    @PatchMapping("/talent/edit")
    public ResponseResult editTalentPost(ServletRequest request, @RequestParam("postId")Long postId,
                                         @RequestPart MultipartFile file,
                                         @RequestParam String title, @RequestParam String content,
                                         @RequestParam String completionTime,@RequestParam boolean emergency,
                                         @RequestParam String errandAddress,@RequestParam int maxPersonNum,
                                         @RequestParam int price, @RequestParam Long categoryDetailId) throws IOException {

        String fullPath = null;
        if (!file.isEmpty()) {
            fullPath = fileDir + file.getOriginalFilename();
            file.transferTo(new File(fullPath));
        }

        return talentPostService.postEdit(request, postId, fullPath, title, content, completionTime, emergency, errandAddress,
                maxPersonNum, price, categoryDetailId);
    }
}
