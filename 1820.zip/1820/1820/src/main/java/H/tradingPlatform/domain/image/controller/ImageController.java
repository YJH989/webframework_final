package H.tradingPlatform.domain.image.controller;

import H.tradingPlatform.ResponseResult;
import H.tradingPlatform.domain.image.service.ImageService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletRequest;
import java.io.File;
import java.io.IOException;

@RestController
@RequiredArgsConstructor
public class ImageController {

    private final ImageService imageService;

    @Value("${file.dir}")
    private String fileDir;

    @PostMapping("/members/upload")
    public ResponseResult saveFile(ServletRequest request,
                                   @RequestPart MultipartFile file) throws IOException {

        String fullPath = null;
        if (!file.isEmpty()) {
            fullPath = fileDir + file.getOriginalFilename();
            file.transferTo(new File(fullPath));
        }

        return imageService.saveProfileImage(request, fullPath);
    }

}
