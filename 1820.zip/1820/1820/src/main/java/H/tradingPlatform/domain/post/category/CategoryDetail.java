package H.tradingPlatform.domain.post.category;

import H.tradingPlatform.domain.post.talentPost.TalentPost;
import lombok.Getter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
public class CategoryDetail {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "category_detail_id")
    private Long categoryDetailId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;

    @Column(unique = true)
    private String name;
}
