package H.tradingPlatform.domain.member.dto;

import H.tradingPlatform.domain.member.MemberGender;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
public class MemberEditDto {

    private MemberGender gender;

    @NotBlank(message = "이름은 필수 입니다.")
    private String name;

    @NotBlank(message = "비밀번호는 필수 입니다.")
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,20}",
            message = "비밀번호는 영문 대 소문자, 숫자, 특수문자($@$!%*?&)를 사용하세요. 비밀번호는 8~20자 입니다.")
    private String password;
}
