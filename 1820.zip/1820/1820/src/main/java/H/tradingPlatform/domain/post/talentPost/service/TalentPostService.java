package H.tradingPlatform.domain.post.talentPost.service;

import H.tradingPlatform.ResponseResult;
import H.tradingPlatform.authentication.JwtTokenProvider;
import H.tradingPlatform.domain.image.Image;
import H.tradingPlatform.domain.image.dto.ImageResponseDto;
import H.tradingPlatform.domain.image.repository.ImageRepository;
import H.tradingPlatform.domain.member.JoinMembers;
import H.tradingPlatform.domain.member.Member;
import H.tradingPlatform.domain.member.dto.JoinMemberDto;
import H.tradingPlatform.domain.member.repository.MemberRepository;
import H.tradingPlatform.domain.post.category.CategoryDetail;
import H.tradingPlatform.domain.post.category.repository.CategoryDetailRepository;
import H.tradingPlatform.domain.post.talentPost.TalentPost;
import H.tradingPlatform.domain.post.talentPost.dto.*;
import H.tradingPlatform.domain.post.talentPost.repository.TalentPostRepository;
import H.tradingPlatform.exception.dto.ErrorResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.stream.Collectors;

import static H.tradingPlatform.authentication.filter.JwtAuthenticationFilter.resolveToken;

@Service
@Transactional
@RequiredArgsConstructor
public class TalentPostService {

    private final TalentPostRepository talentPostRepository;
    private final MemberRepository memberRepository;
    private final JwtTokenProvider jwtTokenProvider;
    private final CategoryDetailRepository categoryDetailRepository;
    private final ImageRepository imageRepository;

    public ResponseResult findTalentPosts(int offset, int limit){
        List<TalentPost> posts = talentPostRepository.findAll(offset, limit);
        List<TalentPostsListResponseDto> collect = posts.stream()
                .map(m -> new TalentPostsListResponseDto(m.getMember().getName(), m.getPostId(), m.getTitle(), m.getViews(), m.isEmergency(), m.getDateTime().getCreatedAt(),m.getPrice()))
                .collect(Collectors.toList());

        return new ResponseResult(HttpStatus.OK.value(), collect);
    }

    public ResponseResult findTalentPostDetail(ServletRequest request, Long postId){
        String token = resolveToken((HttpServletRequest) request);
        String loginId = "";
        // 2. validateToken 으로 토큰 유효성 검사
        if (token != null && jwtTokenProvider.validateToken(token)) {
            // 토큰이 유효할 경우 토큰에서 Authentication 객체를 가지고 와서 SecurityContext 에 저장
            Authentication authentication = jwtTokenProvider.getAuthentication(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loginId = authentication.getName();
        }
        if(loginId == ""){
            ErrorResponseDto errorResponseDto = new ErrorResponseDto("잘못된 토큰입니다. 재로그인 후 이용해주세요.");
            return new ResponseResult(HttpStatus.FORBIDDEN.value(),errorResponseDto);
        }else{
            TalentPost post = talentPostRepository.findOne(postId);
            boolean isMine;
            if(loginId.equals(post.getMember().getLoginId())){
                isMine = true;
            }else{
                isMine = false;
            }

            List<JoinMembers> joinMembersId = post.getJoinMembers();
            boolean participant = false;
            for (JoinMembers joinMembers : joinMembersId) {
                if(loginId.equals(joinMembers.getMember().getLoginId())){
                    participant = true;
                }else{
                    participant = false;
                }
            }
            String[] imageUrlSplit = post.getImage().getImageUrl().split("\\\\");
            String imageUrl = imageUrlSplit[imageUrlSplit.length-2]+"\\"+imageUrlSplit[imageUrlSplit.length-1];
            TalentPostDetail talentPostDetail = new TalentPostDetail(post.getMember().getName(),
                    post.getTitle(),post.getViews(),post.getRecommendations(),post.getPrice(),
                    post.isEmergency(), post.getDateTime().getCreatedAt(),post.getContent(),
                    post.getJoinMembers().size(), isMine, participant, post.getMaxPersonNum(),
                    post.getErrandAddress(), post.getCompletionTime(), post.getCategoryDetail().getCategoryDetailId(),
                    imageUrl);

            return new ResponseResult(HttpStatus.OK.value(),talentPostDetail);
        }
    }

    public ResponseResult addJoinMember(ServletRequest request,Long postId){
        String token = resolveToken((HttpServletRequest) request);
        String loginId = "";
        // 2. validateToken 으로 토큰 유효성 검사
        if (token != null && jwtTokenProvider.validateToken(token)) {
            // 토큰이 유효할 경우 토큰에서 Authentication 객체를 가지고 와서 SecurityContext 에 저장
            Authentication authentication = jwtTokenProvider.getAuthentication(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loginId = authentication.getName();
        }
        if(loginId == ""){
            ErrorResponseDto errorResponseDto = new ErrorResponseDto("잘못된 토큰입니다. 재로그인 후 이용해주세요.");
            return new ResponseResult(HttpStatus.FORBIDDEN.value(),errorResponseDto);
        }else{
            Member findMember = memberRepository.findByLoginId(loginId);
            TalentPost findPost = talentPostRepository.findOne(postId);
            JoinMembers joinMembers = new JoinMembers();
            joinMembers.setMember(findMember);
            joinMembers.setPost(findPost);
            talentPostRepository.saveJoinMember(joinMembers);
            JoinMemberDto joinMemberDto = new JoinMemberDto(joinMembers.getJoinMembersId(),"참여 됐습니다.");
            return new ResponseResult(HttpStatus.CREATED.value(), joinMemberDto);
        }
    }

    public ResponseResult post(ServletRequest request, String fullPath, String title, String content,
                               String completionTime, boolean emergency, String errandAddress, int maxPersonNum,
                               int price, Long categoryDetailId){
        String token = resolveToken((HttpServletRequest) request);
        String loginId = "";
        // 2. validateToken 으로 토큰 유효성 검사
        if (token != null && jwtTokenProvider.validateToken(token)) {
            // 토큰이 유효할 경우 토큰에서 Authentication 객체를 가지고 와서 SecurityContext 에 저장
            Authentication authentication = jwtTokenProvider.getAuthentication(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loginId = authentication.getName();
        }
        if(loginId == ""){
            ErrorResponseDto errorResponseDto = new ErrorResponseDto("잘못된 토큰입니다. 재로그인 후 이용해주세요.");
            return new ResponseResult(HttpStatus.FORBIDDEN.value(),errorResponseDto);
        }else{
            Member findMember = memberRepository.findByLoginId(loginId);
            Image image = new Image(fullPath);
            CategoryDetail findCategoryDetail = categoryDetailRepository.findByCategoryDetailId(categoryDetailId);
            TalentPost talentPost = new TalentPost(title, content, findMember, price, errandAddress,
                    emergency,findCategoryDetail, completionTime, maxPersonNum);

            TalentPost saveTalentPost = talentPostRepository.save(talentPost);
            image.setPost(saveTalentPost);
            imageRepository.saveImage(image);
            PostTalentPostResponseDto postTalentPostResponseDto = new PostTalentPostResponseDto(saveTalentPost.getPostId(),"게시글 작성이 완료되었습니다.");
            return new ResponseResult(HttpStatus.CREATED.value(), postTalentPostResponseDto);
        }
    }

    public ResponseResult viewPlus(ServletRequest request,Long postId){
        String token = resolveToken((HttpServletRequest) request);
        String loginId = "";
        // 2. validateToken 으로 토큰 유효성 검사
        if (token != null && jwtTokenProvider.validateToken(token)) {
            // 토큰이 유효할 경우 토큰에서 Authentication 객체를 가지고 와서 SecurityContext 에 저장
            Authentication authentication = jwtTokenProvider.getAuthentication(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loginId = authentication.getName();
        }
        if(loginId == ""){
            ErrorResponseDto errorResponseDto = new ErrorResponseDto("잘못된 토큰입니다. 재로그인 후 이용해주세요.");
            return new ResponseResult(HttpStatus.FORBIDDEN.value(),errorResponseDto);
        }else{
            TalentPost findPost = talentPostRepository.findOne(postId);
            findPost.viewPlus();
            ViewRecommendPlusDto viewRecommendPlusDto = new ViewRecommendPlusDto("조회수 1 증가");
            return new ResponseResult(HttpStatus.CREATED.value(), viewRecommendPlusDto);
        }
    }

    public ResponseResult recommendPlus(ServletRequest request,Long postId){
        String token = resolveToken((HttpServletRequest) request);
        String loginId = "";
        // 2. validateToken 으로 토큰 유효성 검사
        if (token != null && jwtTokenProvider.validateToken(token)) {
            // 토큰이 유효할 경우 토큰에서 Authentication 객체를 가지고 와서 SecurityContext 에 저장
            Authentication authentication = jwtTokenProvider.getAuthentication(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loginId = authentication.getName();
        }
        if(loginId == ""){
            ErrorResponseDto errorResponseDto = new ErrorResponseDto("잘못된 토큰입니다. 재로그인 후 이용해주세요.");
            return new ResponseResult(HttpStatus.FORBIDDEN.value(),errorResponseDto);
        }else{
            TalentPost findPost = talentPostRepository.findOne(postId);
            findPost.recommendationPlus();
            ViewRecommendPlusDto viewRecommendPlusDto = new ViewRecommendPlusDto("추천 1 증가");
            return new ResponseResult(HttpStatus.CREATED.value(), viewRecommendPlusDto);
        }
    }

    public ResponseResult complete(Long postId){
        TalentPost findPost = talentPostRepository.findOne(postId);
        findPost.changeStatus();
        ViewRecommendPlusDto viewRecommendPlusDto = new ViewRecommendPlusDto("완료되었습니다.");
        return new ResponseResult(HttpStatus.CREATED.value(), viewRecommendPlusDto);
    }

    public ResponseResult postEdit(ServletRequest request, Long postId, String fullPath, String title, String content,
                               String completionTime, boolean emergency, String errandAddress, int maxPersonNum,
                               int price, Long categoryDetailId){
        String token = resolveToken((HttpServletRequest) request);
        String loginId = "";
        // 2. validateToken 으로 토큰 유효성 검사
        if (token != null && jwtTokenProvider.validateToken(token)) {
            // 토큰이 유효할 경우 토큰에서 Authentication 객체를 가지고 와서 SecurityContext 에 저장
            Authentication authentication = jwtTokenProvider.getAuthentication(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loginId = authentication.getName();
        }
        if(loginId == ""){
            ErrorResponseDto errorResponseDto = new ErrorResponseDto("잘못된 토큰입니다. 재로그인 후 이용해주세요.");
            return new ResponseResult(HttpStatus.FORBIDDEN.value(),errorResponseDto);
        }else{
            TalentPost findPost = talentPostRepository.findOne(postId);
            CategoryDetail findCategoryDetail = categoryDetailRepository.findByCategoryDetailId(categoryDetailId);
            findPost.getImage().setImageUrl(fullPath);
            findPost.setCategoryDetail(findCategoryDetail);
            findPost.edit(title,content);
            findPost.editPost(completionTime,emergency,errandAddress,maxPersonNum,price);
            ViewRecommendPlusDto viewRecommendPlusDto = new ViewRecommendPlusDto("수정되었습니다.");

            return new ResponseResult(HttpStatus.CREATED.value(), viewRecommendPlusDto);
        }
    }
}
