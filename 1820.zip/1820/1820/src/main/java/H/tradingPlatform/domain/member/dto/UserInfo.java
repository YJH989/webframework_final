package H.tradingPlatform.domain.member.dto;

import H.tradingPlatform.domain.member.MemberGender;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
@AllArgsConstructor
public class UserInfo {

    private String name;
    private String email;
    private MemberGender gender;
    private String image;
}
