package H.tradingPlatform.domain.post.talentPost.dto;

import H.tradingPlatform.domain.DateTime;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TalentPostDetail {

    private String name;
    private String title;
    private Long views;
    private Long recommendations;
    private int price;
    private boolean emergency;
    private String createdAt;
    private String content;
    private int joinMemberCount;
    private boolean isMine;
    private boolean participant;
    private int maxPersonNum;
    private String errandAddress;
    private String completionTime;
    private Long categoryDetailId;
    private String imageUrl;
}
