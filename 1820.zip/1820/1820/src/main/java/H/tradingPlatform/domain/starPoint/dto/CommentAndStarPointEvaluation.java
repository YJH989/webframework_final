package H.tradingPlatform.domain.starPoint.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommentAndStarPointEvaluation {
    @NotNull
    private String comment;
    @NotNull
    private Long postId;
    @NotNull
    private int attitudePoint;
    @NotNull
    private int beneficialPoint;
    @NotNull
    private int professionalPoint;
}
