import React from 'react';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';

class Showcomment extends React.Component {
    render() {
        return (
            <TableRow aligin="center">
                <TableCell>{this.props.name}</TableCell>
                <TableCell>{this.props.attitudePoint}</TableCell>
                <TableCell>{this.props.beneficialPoint}</TableCell>
                <TableCell>{this.props.professionalPoint}</TableCell>
                <TableCell>{this.props.comment}</TableCell>
                <TableCell>{this.props.history}</TableCell>
                <TableCell>{this.props.createdAt}</TableCell>
            </TableRow>
        )

    }
}


export default Showcomment;