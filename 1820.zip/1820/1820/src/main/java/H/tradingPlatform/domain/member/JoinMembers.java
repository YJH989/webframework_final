package H.tradingPlatform.domain.member;

import H.tradingPlatform.domain.post.Post;
import lombok.Getter;

import javax.persistence.*;

@Entity
@Getter
public class JoinMembers {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "joinMembers_id")
    private Long joinMembersId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id")
    private Member member;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "post_id")
    private Post post;

    public void setMember(Member member){
        this.member = member;
        member.getJoinMembers().add(this);
    }

    public void setPost(Post post){
        this.post = post;
        post.getJoinMembers().add(this);
    }
}
