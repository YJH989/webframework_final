package H.tradingPlatform.domain.member;

import H.tradingPlatform.domain.DateTime;
import H.tradingPlatform.domain.starPoint.StarPoint;
import H.tradingPlatform.domain.image.Image;
import H.tradingPlatform.domain.post.Post;
import lombok.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PROTECTED)
public class Member implements UserDetails{
    //로그인에서 사용되는 아이디
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "member_id")
    private Long memberId;

    @Column(unique = true)
    private String loginId;

    private String password;

    @Column(unique = true)
    private int studentId;

    private String name;

    @Enumerated(EnumType.STRING)
    private MemberGender gender;

    @Column(unique = true)
    private String email;

    @ElementCollection(fetch = FetchType.LAZY)
    private List<String> roles = new ArrayList<>();

    private String birthDate;

    @Embedded //생성일 수정일 삭제일
    private DateTime dateTime;

    @OneToMany(mappedBy = "member")
    private List<Post> posts = new ArrayList<>();

    @OneToMany(mappedBy = "participants")
    private List<StarPoint> participantsStarPoints = new ArrayList<>();

    @OneToMany(mappedBy = "contributor")
    private List<StarPoint> contributorStarPoints = new ArrayList<>();

    //프로필 사진
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "profile_image")
    @Setter
    private Image profileImage;

    @OneToMany(mappedBy = "member")
    private List<JoinMembers> joinMembers = new ArrayList<>();

    @Builder
    public Member(String loginId, String password, int studentId, String name, MemberGender gender, String email, List<String> roles, String birthDate, DateTime dateTime) {
        this.loginId = loginId;
        this.password = password;
        this.studentId = studentId;
        this.name = name;
        this.gender = gender;
        this.email = email;
        this.roles = roles;
        this.birthDate = birthDate;
        this.dateTime = dateTime;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.roles.stream()
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
    }

    @Override
    public String getUsername() {
        return loginId;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public void updatePassword(String password){
        this.password = password;
    }

    public void updateGender(MemberGender gender){
        this.gender = gender;
    }

    public void updateName(String name){
        this.name = name;
    }
}