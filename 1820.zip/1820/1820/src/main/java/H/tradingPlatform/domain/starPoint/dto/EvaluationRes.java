package H.tradingPlatform.domain.starPoint.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EvaluationRes {

    private String message;
}
