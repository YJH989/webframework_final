package H.tradingPlatform.domain.member.controller;

import H.tradingPlatform.ResponseResult;
import H.tradingPlatform.domain.member.dto.JoinRequestDto;
import H.tradingPlatform.domain.member.dto.MemberEditDto;
import H.tradingPlatform.domain.member.dto.MemberLoginRequestDto;
import H.tradingPlatform.domain.member.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

@Slf4j
@RestController
@RequiredArgsConstructor
public class MemberController {
    private final MemberService memberService;

    @PostMapping("/join")
    public ResponseResult join(@RequestBody @Valid JoinRequestDto joinRequestDto) {
        return memberService.join(joinRequestDto);
    }

    @PostMapping("/login")
    public ResponseResult login(@RequestBody @Valid MemberLoginRequestDto memberLoginRequestDto) {
        String loginId = memberLoginRequestDto.getLoginId();
        String password = memberLoginRequestDto.getPassword();
        return memberService.login(loginId, password);
    }

    @GetMapping("/members/self")
    public ResponseResult myPage(ServletRequest request,@RequestParam("offset")int offset,@RequestParam("limit")int limit){

        return memberService.MemberPage(request,offset,limit);
    }

    @PatchMapping("/members/quit")
    public ResponseResult quit(ServletRequest request){
        return memberService.quit(request);
    }

    @PatchMapping("/members/edit")
    public ResponseResult edit(ServletRequest request, @RequestBody @Valid MemberEditDto memberEditDto){

        return memberService.edit(request, memberEditDto.getGender(), memberEditDto.getName(), memberEditDto.getPassword());
    }
}