import React from 'react';
//import CommonTable from '../table/CommonTable';
import CommonTableColumn from '../components/table/CommonTableColumn';
import CommonTableRow from '../components/table/CommonTableRow';


const Post=({postId,price,title,name,createdAt,recommendations,views})=>{
    return(
        <>
        <CommonTableRow key={postId} event={postId} >
          <CommonTableColumn>{ name }</CommonTableColumn>
          <CommonTableColumn>{ recommendations }</CommonTableColumn>
          <CommonTableColumn>{ title }</CommonTableColumn>
          <CommonTableColumn>{ price }</CommonTableColumn>
          <CommonTableColumn>{ views }</CommonTableColumn>
          <CommonTableColumn>{ createdAt }</CommonTableColumn>
        </CommonTableRow>        
        </>
    )
}
export default Post;