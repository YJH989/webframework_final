package H.tradingPlatform.domain.starPoint;

import H.tradingPlatform.domain.DateTime;
import H.tradingPlatform.domain.member.Member;
import H.tradingPlatform.domain.post.talentPost.TalentPost;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import javax.persistence.*;

@Entity
@Getter
public class StarPoint {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "star_point_id")
    private Long starPointId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "participants_id")
    private Member participants;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "contributor_id")
    private Member contributor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "talentPost_id")
    private TalentPost talentPost;

    //적립 날짜
    @Embedded
    private DateTime dateTime;

    private int attitudePoint;

    private int beneficialPoint;

    private int professionalPoint;

    private String history;

    private String comment;

    @Builder
    public StarPoint(Member participants, Member contributor, TalentPost talentPost, DateTime dateTime,
                     int attitudePoint, int beneficialPoint, int professionalPoint,
                     String history, String comment){
        this.participants = participants;
        this.contributor = contributor;
        this.talentPost = talentPost;
        this.dateTime = dateTime;
        this.attitudePoint = attitudePoint;
        this.beneficialPoint = beneficialPoint;
        this.professionalPoint = professionalPoint;
        this.history = history;
        this.comment = comment;
    }

    public StarPoint() {

    }

    public void setParticipants(Member participants){
        this.participants = participants;
        participants.getParticipantsStarPoints().add(this);
    }

    public void setContributor(Member contributor){
        this.contributor = contributor;
        contributor.getContributorStarPoints().add(this);
    }
}
