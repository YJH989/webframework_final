package H.tradingPlatform.domain.starPoint.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class StarPointResponseDto {

    private List<SearchEvaluationDto> searchEvaluationDtos;
    private Integer attitudePointSum;
    private Integer beneficialPointSum;
    private Integer professionalPointSum;
}
