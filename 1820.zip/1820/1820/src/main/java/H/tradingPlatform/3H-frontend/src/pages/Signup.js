import React, { useState } from 'react';
import axios from "axios";
import {
  Avatar,
  Button,
  CssBaseline,
  TextField,
  FormControl,
  FormControlLabel,
  Checkbox,
  FormHelperText,
  Grid,
  Box,
  Typography,
  Container,
} from '@mui/material/';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import NativeSelect from '@mui/material/NativeSelect';


var SERVER_URL = require("../test");

const Signup = () => {
  const theme = createTheme();
  const [checked, setChecked] = useState(false);

  // form 전송
  const handleSubmit = async (e) => {
    e.preventDefault();
    const loginId = e.target.loginId.value;
    const password = e.target.password.value;
    const studentId = e.target.studentId.value;
    const name = e.target.name.value;
    const gender = e.target.gender.value;
    const email = e.target.email.value;
    const birthDate = e.target.birthDate.value;

     await axios.post(SERVER_URL.test() + "join", { loginId, password, studentId, name, gender, email, birthDate}) //정보 일치 시 response로 토큰을 받는다
               .then((response) => {
                 if(response.data.status === 201) {
                  alert('회원가입이 완료되었습니다.');
                  document.location.href = '/Login';
                 }
                 else if(response.data.status === 400) {
                  if(response.data.data[0].message != null) {
                    alert(response.data.data[0].message);
                  }
                  if(response.data.data[1].message != null) {
                    alert(response.data.data[1].message);
                  }
                 }
               })
  };
  const [value, setValue] = useState("")

  const onChange = (event) => {
    setValue(event.currentTarget.value)
  }

  const validation =()=>{
    let check = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,20}/;
    return check.test(value);
  }

  return (
    <ThemeProvider theme={theme}>

        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
        >
          <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }} />
          <Typography component="h1" variant="h5">
            회원가입
          </Typography>
          <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
            <FormControl component="fieldset" variant="standard">
              <Grid container spacing={2}>
                <Grid item xs={12}>
                <p className="mt-3 font-semibold text-1xl" style={{color:"gray"}}>아이디</p><br/>
                  <TextField
                    required
                    autoFocus
                    fullWidth
                    id="loginId"
                    name="loginId"
                    label="아이디 (5~20자리)"
                  />
                </Grid>
                <Grid item xs={12}>
                <p className="mt-3 font-semibold text-1xl" style={{color:"gray"}}>비밀번호</p><br/>
                  <TextField
                    required
                    fullWidth
                    type="password"
                    id="password"
                    name="password"
                    label="비밀번호 (8~20자리 대소문자 숫자 특수문자)"
                    onChange={onChange}
                    value={value}
                    error={!validation()}
                    helperText={validation() ? "":"8~20자리 대소문자 숫자 특수문자를 입력하라굿~ 훗"}
                  />
                </Grid>
                <Grid item xs={12}>
                <p className="mt-3 font-semibold text-1xl" style={{color:"gray"}}>학번</p><br/>
                  <TextField
                    required
                    fullWidth
                    id="studentId"
                    name="studentId"
                    label="학번 입력"
                  />
                </Grid>
                <Grid item xs={12}>
                <p className="mt-3 font-semibold text-1xl" style={{color:"gray"}}>이름</p><br/>
                  <TextField required fullWidth id="name" name="name" label="이름" />
                </Grid>
                <Grid item xs={12}>
                <p className="mt-3 font-semibold text-1xl" style={{color:"gray"}}>성별</p><br/>
                <FormControl>
                                    <NativeSelect defaultValue={30} name="gender">
                                        <option value="MALE">MALE</option>
                                        <option value="FEMALE">FEMALE</option>
                                    </NativeSelect>
                                </FormControl><br/><br/>
                </Grid>
                <Grid item xs={12}>
                <p className="mt-3 font-semibold text-1xl" style={{color:"gray"}}>이메일 주소</p><br/>
                  <TextField
                    required
                    autoFocus
                    fullWidth
                    type="email"
                    id="email"
                    name="email"
                    label="이메일 주소"
                  />
                </Grid>
                <Grid item xs={12}>
                <p className="mt-3 font-semibold text-1xl" style={{color:"gray"}}>생년월일</p><br/>
                  <TextField
                    required
                    autoFocus
                    fullWidth
                    id="birthDate"
                    name="birthDate"
                    label="생년월일(YYMMDD)"
                  />
                </Grid>
            </Grid>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                size="large"
              >
                회원가입
              </Button>
            </FormControl>
          </Box>
        </Box>
    </ThemeProvider>
  );
};
export default Signup;