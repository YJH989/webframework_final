package H.tradingPlatform.domain.starPoint.repository;

import H.tradingPlatform.domain.starPoint.StarPoint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SimpleStarPointRepository extends JpaRepository<StarPoint, Long> {

    @Query(value = "select SUM(attitude_point) from star_point where contributor_id = :memberId",nativeQuery = true)
    Integer findAttitudeStarPointSum(@Param("memberId") Long memberId);

    @Query(value = "select SUM(beneficial_point) from star_point where contributor_id = :memberId",nativeQuery = true)
    Integer findBeneficialStarPointSum3(@Param("memberId") Long memberId);

    @Query(value = "select SUM(professional_point) from star_point where contributor_id = :memberId",nativeQuery = true)
    Integer findProfessionalStarPointSum(@Param("memberId") Long memberId);
}
