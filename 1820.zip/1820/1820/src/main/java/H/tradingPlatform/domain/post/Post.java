package H.tradingPlatform.domain.post;

import H.tradingPlatform.domain.DateTime;
import H.tradingPlatform.domain.image.Image;
import H.tradingPlatform.domain.member.JoinMembers;
import H.tradingPlatform.domain.member.Member;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "DTYPE")
@Getter
@NoArgsConstructor
public class Post {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "post_id")
    private Long postId;

    private String title;

    @Column(columnDefinition = "TEXT")
    private String content;

    //조회수
    private Long views;

    @Embedded
    private DateTime dateTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id")
    private Member member;

    @OneToOne(mappedBy = "post",cascade = CascadeType.ALL)
    @Setter
    private Image image;

    @OneToMany(mappedBy = "post")
    private List<JoinMembers> joinMembers;

    public Post(String title, String content, Member member) {
        this.title = title;
        this.content = content;
        this.views = 0L;
        this.dateTime = new DateTime(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),null,null);
        setMember(member);
    }

    public void setMember(Member member){
        this.member = member;
        member.getPosts().add(this);
    }

    public void viewPlus(){
        this.views += 1;
    }

    public void edit(String title, String content){
        this.title = title;
        this.content = content;
        this.dateTime.updatedAtUpdate();
    }
}
