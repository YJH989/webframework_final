import React,{useState,useEffect,useRef} from 'react';
import axios from 'axios';
import { Link,useNavigate  } from 'react-router-dom';
import Pagination from "../components/table/Pagination";
import './postCss/Post.css';
import CommonTable from '../components/table/CommonTable';
import styled from "styled-components";
import getCookie from '../hooks/getCookie';
import Customer from '../components/table/Customer';

let usercookie = `Bearer${getCookie('id')}`;

var SERVER_URL = require("../test");



const Board=()=>  {
  const [posts,setPosts]=useState([]) // 모든 게시글 저장하는 상태변수
  const [limit, setLimit]=useState(6); // 한 페이지 당 게시글 몇 개씩 보여줄지
  const [page,setPage] =useState(1);  //현제 페이지 번호 = 1번   
  const offset = (page -1) *limit;  

  const [len,setLen] =useState(0)


  useEffect(()=>{
    async function getData(){
      try{
        const response = await axios.get(SERVER_URL.test()+"talents", {
          params: { "offset":offset, "limit":limit },
          headers: {
           Authorization: `Bearer${getCookie('id')}`,
          },
       })
       
        await setPosts(response.data)
        await setLen(response.data.data.length)
      }catch(error){console.error(error)};
      
    }
    getData();

    
    },[offset]);
    const { data } = posts
    const navigate = useNavigate();

    return (
          <>
  
            <div className="wrapper">
            <main>
              
            <div className="title">재능 게시판</div>
                {usercookie === "Bearerundefined" ?
                    <>
                        <br/> <br/>
                    </> :
                    <>
                        <button className="createButton" onClick={() => navigate("write")}>작성하기</button>
                    </> }

            <CommonTable headersName={['번호','제목', '이름', '가격', '긴급여부','조회수','등록일']}>

              {Array.isArray(posts.data) ?
              posts.data.map((post)=>(  
                <Customer
                   key={post.postId}
                   postId={post.postId}
                   title={post.title}
                   name={post.name}
                   price={post.price}
                   emergency={post.emergency ? "긴급여부O" : "긴급여부X"}
                   views={post.views}
                   createdAt={post.createdAt}
                />
              ))
            : null
            }
            </CommonTable>
            </main>
            </div>
            <div>
            <footer>
            <Pagination total={len} limit={limit} page={page} setPage={setPage}/>
            </footer>
            </div>
          </>  
    )
}


const Layout = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  max-width: 800px;
  margin: 0 auto;
`;

export default Board;






