package H.tradingPlatform.domain.starPoint.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SearchEvaluationDto {

    private String name;
    private int attitudePoint;
    private int beneficialPoint;
    private int professionalPoint;
    private String  comment;
    private String history;
    private String createdAt;
}
