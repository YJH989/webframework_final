package H.tradingPlatform.domain.post;

public enum RecruitmentStatus {
    RECRUITING, COMPLETION
}
