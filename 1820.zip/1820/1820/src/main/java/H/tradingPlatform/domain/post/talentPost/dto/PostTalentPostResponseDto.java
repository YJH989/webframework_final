package H.tradingPlatform.domain.post.talentPost.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PostTalentPostResponseDto {

    private Long postId;
    private String message;
}
