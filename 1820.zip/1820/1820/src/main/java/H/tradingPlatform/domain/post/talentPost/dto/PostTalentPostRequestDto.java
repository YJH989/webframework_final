package H.tradingPlatform.domain.post.talentPost.dto;

import lombok.Data;

@Data
public class PostTalentPostRequestDto {

    private String title;
    private String content;
    private String completionTime;
    private boolean emergency;
    private String errandAddress;
    private int maxPersonNum;
    private int price;
    private Long categoryDetailId;
}
