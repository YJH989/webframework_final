package H.tradingPlatform.domain.image.service;

import H.tradingPlatform.ResponseResult;
import H.tradingPlatform.authentication.JwtTokenProvider;
import H.tradingPlatform.domain.image.Image;
import H.tradingPlatform.domain.image.dto.ImageResponseDto;
import H.tradingPlatform.domain.image.repository.ImageRepository;
import H.tradingPlatform.domain.member.Member;
import H.tradingPlatform.domain.member.repository.MemberRepository;
import H.tradingPlatform.domain.post.talentPost.repository.TalentPostRepository;
import H.tradingPlatform.exception.dto.ErrorResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import static H.tradingPlatform.authentication.filter.JwtAuthenticationFilter.resolveToken;

@Service
@RequiredArgsConstructor
@Transactional
public class ImageService {

    private final ImageRepository imageRepository;
    private final JwtTokenProvider jwtTokenProvider;
    private final MemberRepository memberRepository;

    public ResponseResult saveProfileImage(ServletRequest request, String fullPath){
        String token = resolveToken((HttpServletRequest) request);
        String loginId = "";
        // 2. validateToken 으로 토큰 유효성 검사
        if (token != null && jwtTokenProvider.validateToken(token)) {
            // 토큰이 유효할 경우 토큰에서 Authentication 객체를 가지고 와서 SecurityContext 에 저장
            Authentication authentication = jwtTokenProvider.getAuthentication(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loginId = authentication.getName();
        }
        if(loginId == ""){
            ErrorResponseDto errorResponseDto = new ErrorResponseDto("잘못된 토큰입니다. 재로그인 후 이용해주세요.");
            return new ResponseResult(HttpStatus.FORBIDDEN.value(),errorResponseDto);
        }else{
            Member findMember = memberRepository.findByLoginId(loginId);
            Image image = new Image(fullPath);
            image.setMember(findMember);
            Long imageId = imageRepository.saveImage(image);
            ImageResponseDto imageResponseDto = new ImageResponseDto(imageId, fullPath,"이미지 저장에 성공했습니다.");

            return new ResponseResult(HttpStatus.CREATED.value(), imageResponseDto);
        }
    }
}
