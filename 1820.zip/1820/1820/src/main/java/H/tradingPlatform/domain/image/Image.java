package H.tradingPlatform.domain.image;

import H.tradingPlatform.domain.member.Member;
import H.tradingPlatform.domain.post.Post;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@NoArgsConstructor
public class Image {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "image_id")
    private Long imageId;

    @Column(name = "image_url")
    private String imageUrl;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "post_id")
    private Post post;//어떤 글에서 보여지는 이미지인지

    @OneToOne(fetch = FetchType.LAZY,mappedBy = "profileImage")
    private Member member;

    public Image(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setPost(Post post) {
        this.post = post;
        post.setImage(this);
    }

    public void setMember(Member member) {
        this.member = member;
        member.setProfileImage(this);
    }

    public void setImageUrl(String path){
        this.imageUrl = path;
    }
}
