import React, {useEffect, useState} from "react";
import axios from 'axios';
import ShowComment from "../components/ShowComment";
import Table from '@material-ui/core/Table';
import TableHead from '@material-ui/core/TableHead';
import TableBody from '@material-ui/core/TableBody';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import getCookie from '../hooks/getCookie';
import Pagination from '../components/table/Pagination';
import './commentCss/Comment.css';
import {IoStar} from "react-icons/io5";
import "tailwindcss/tailwind.css";

var SERVER_URL = require("../test");

// 나의 평점 확인 페이지 (누군가에게 받은 별점, 코멘트 확인)


const Comment = (postId) => {

    const [len, setlen] = useState(0);
    const [limit, setLimit] = useState(3); // 한 페이지 당 게시글 몇 개씩 보여줄지
    const [page, setPage] = useState(1);  //현제 페이지 번호 = 1번
    const offset = (page - 1) * limit; //offset부터 limit개까지 보여주기

    const [evaluationdatas, setevaluationdatas] = useState([]); // 내가 받은 평점 저장하는 상태변수
    const [APoint, setAPoint] = useState(0);
    const [BPoint, setBPoint] = useState(0);
    const [PPoint, setPPoint] = useState(0);
    const [sumPoint, setsumPoint] = useState(0);

    useEffect(() => {
        const fetchMyPageData = async () => {
            const response = await axios.get(SERVER_URL.test() + 'evaluation', {
                params: {"offset": offset, "limit": limit},
                headers: {
                    Authorization: `Bearer${getCookie('id')}`,
                },
            })

            setlen(response.data.data.searchEvaluationDtos.length)
            setevaluationdatas(response.data.data.searchEvaluationDtos);
            setAPoint(response.data.data.attitudePointSum == null ? 0 : response.data.data.attitudePointSum);
            setBPoint(response.data.data.beneficialPointSum == null ? 0 : response.data.data.beneficialPointSum);
            setPPoint(response.data.data.professionalPointSum == null ? 0 : response.data.data.professionalPointSum);
            setsumPoint(response.data.data.attitudePointSum + response.data.data.beneficialPointSum + response.data.data.professionalPointSum);
        };
        fetchMyPageData();
    }, [offset]);


    return (
        <React.Fragment>
            <section>
                <div className="title centered text-4xl ">[ 내가 받은 평점 ]</div>

                <Table style={{minWidth: 1080}}>
                    <TableHead>
                        <TableRow align="center">
                            <TableCell>이름</TableCell>
                            <TableCell>태도</TableCell>
                            <TableCell>유익성</TableCell>
                            <TableCell>전문성</TableCell>
                            <TableCell>코멘트</TableCell>
                            <TableCell>내역</TableCell>
                            <TableCell>작성일</TableCell>
                        </TableRow>
                    </TableHead>

                    <TableBody className="tablebody">

                        {Array.isArray(evaluationdatas) ?
                            evaluationdatas.map(c =>
                                (<ShowComment key={c.id} name={c.name} attitudePoint={c.attitudePoint}
                                              beneficialPoint={c.beneficialPoint}
                                              professionalPoint={c.professionalPoint} comment={c.comment}
                                              history={c.history} createdAt={c.createdAt}/>))
                            : null
                        }

                    </TableBody>
                </Table>
            </section>
            <Pagination className="Column" total={len} limit={limit} page={page} setPage={setPage}>
            </Pagination>

            <section>
                <div class="pt-50">
                    <br/>
                    <br/>
                    <div className="title centered text-4xl pt-80">[ 별 포인트 ]</div>
                </div>
                <div class="pt-6">
        <span class="inline-block " className="centered">
        <h2 className="starpoint"><p class="pr-2">[ 태도별 ]</p><IoStar size="40" color="#fbbf24"/> <p class="pl-2">X</p><p
            class="pl-2">{APoint}</p></h2>
        <h2 className="starpoint"><p class="pr-2">[ 유익별 ]</p><IoStar size="40" color="#fbbf24"/> <p class="pl-2">X</p><p
            class="pl-2">{BPoint}</p></h2>
        <h2 className="starpoint"><p class="pr-2">[ 전문별 ]</p><IoStar size="40" color="#fbbf24"/> <p class="pl-2">X</p><p
            class="pl-2">{PPoint}</p></h2>
        <h2 className="starpoint"><p class="pr-2">[ 전체 별 포인트 ]</p><IoStar size="50" color="#fbbf24"/> <p
            class="pl-2">X</p><p class="pl-2">{sumPoint}</p></h2>
        </span>
                </div>
            </section>
            <br/>
            <br/>
            <br/>
        </React.Fragment>

    )
}

export default Comment