package H.tradingPlatform.domain.member.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MemberQuitAndEditDto {

    private Long memberId;
    private String message;
}
