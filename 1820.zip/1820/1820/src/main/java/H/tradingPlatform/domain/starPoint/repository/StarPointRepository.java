package H.tradingPlatform.domain.starPoint.repository;

import H.tradingPlatform.domain.starPoint.StarPoint;
import H.tradingPlatform.domain.starPoint.dto.EvaluationRes;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class StarPointRepository {

    private final EntityManager em;

    public EvaluationRes evaluation(StarPoint starPoint){
        em.persist(starPoint);
        return new EvaluationRes("성공했습니다.");
    }

    public List<StarPoint> searchEvaluation(Long memberId,int offset, int limit){
        return em.createQuery(
                "select s from StarPoint s where s.contributor.memberId = :memberId order by s.dateTime.createdAt desc",StarPoint.class)
                .setParameter("memberId", memberId)
                .setFirstResult(offset)
                .setMaxResults(limit)
                .getResultList();
    }
}
