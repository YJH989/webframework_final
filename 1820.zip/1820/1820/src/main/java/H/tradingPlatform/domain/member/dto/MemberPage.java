package H.tradingPlatform.domain.member.dto;

import H.tradingPlatform.domain.post.talentPost.dto.PostList;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Data
@AllArgsConstructor
public class MemberPage {

    private UserInfo userInfo;
    private List<PostList> postList;
}
