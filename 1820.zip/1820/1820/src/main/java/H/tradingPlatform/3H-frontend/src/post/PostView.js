import axios from 'axios';
import React, { useEffect, useState ,useCallback} from 'react';
import { useParams, useNavigate,Route,Routes,Link } from "react-router-dom";
import './postCss/PostView.css';
import getCookie from '../hooks/getCookie';
import {AiFillLike,AiFillAlert,AiFillTag} from "react-icons/ai";
import {BsFillPersonPlusFill,BsFillEyeFill,BsFillCalendarCheckFill,BsCoin,BsFillPersonFill,BsFillGeoAltFill} from "react-icons/bs";
import {Button} from "@mui/material";

var MAXNUM;
var Rcount=1;
var Jcount=1;
var SERVER_URL = require("../test");

const PostView = () => {
    const [ posts, setPosts ] = useState([]);
    const [ datas, setDatas ] = useState([]);
    const [img, setImg] = useState({file: [],});
    const params = useParams();
    const navigate = useNavigate();
    const id = params.id;
    const [RecNum, setRecNum] = useState();
    const [JoinNum, setJoinNum] = useState();
    const [Participant,setParticipant]=useState(false)
    const getData = async () => {
        try {
            //응답 성공
            const response = await axios.get(SERVER_URL.test() + 'talent/detail', {
                params: {"postId": id},
                headers: {
                    Authorization: `Bearer${getCookie('id')}`,
                },
            })
            setPosts(response.data);
            setDatas(response.data.data);
            setImg(response.data.data.imageUrl);
            MAXNUM=response.data.data.maxPersonNum;
            setJoinNum(response.data.data.joinMemberCount)
            setRecNum(response.data.data.recommendations)
            setParticipant(response.data.data.participant)
        } catch (error) {
            console.error(error);
        }
    }
    useEffect(() => {
        getData();
        addViewCount();

    }, []);
useEffect(()=>{

},[RecNum])
    

    const [RecDisable, setRecDisable] = useState(false);
    //추천 버튼     
    const addRecommendations=()=>{
        try {
            Rcount -=1;
            setRecNum(RecNum+1)
            setRecDisable(true);
            axios({
                method:"post",
                url:SERVER_URL.test()+"talent/reco",
                params: {"postId": id},
                headers:{
                    Authorization: `Bearer${getCookie('id')}`,
                },
            })
            .then((response) => {
                alert(response.data.data.message)
        })

        }catch (error) {
            console.error(error);
        }
    }
    //조회수 증가
    const addViewCount=async ()=>{
        try {
            axios({
                method:"post",
                url:SERVER_URL.test()+"talent/views",
                params: {"postId": id},
                headers:{
                    Authorization: `Bearer${getCookie('id')}`,
                },
            })
        }
        catch (error) {
            console.error(error);
        }
    }
    //참여 버튼 
    const join=()=>{
        try {
            Jcount-=1;
            setJoinNum(JoinNum+1)
            axios({
                method:"post",
                url:SERVER_URL.test()+"talent/join",
                params: {"postId": id},
                headers:{
                    Authorization: `Bearer${getCookie('id')}`,
                },
            })
            .then((response) => {
                alert(response.data.data.message)
        })
        setParticipant(true)
        }catch (error) {
            console.error(error);
        }
    }
    //완료 버튼
    const goPage=(id)=>{
        axios({
            method:"post",
            url:SERVER_URL.test()+"talent/complete",
            params: {"postId": id},
            headers:{
                Authorization: `Bearer${getCookie('id')}`,
            },
        })
        .then((response) => {
            alert(response.data.data.message)
    })
        navigate(`/postcomment/${id}`,{state:{postId:id}});
    }


    const isCategory=()=>{
        if(datas.categoryDetailId==1)
            return <label>뷰티</label>
        if(datas.categoryDetailId==2)
            return <label>스포츠</label>
        if(datas.categoryDetailId==3)
            return <label>외국어</label>
        if(datas.categoryDetailId==4)
            return <label>프로그래밍</label>
        if(datas.categoryDetailId==5)
            return <label>운동</label>
        if(datas.categoryDetailId==6)
            return <label>악기</label>
        if(datas.categoryDetailId==7)
            return <label>기타</label>
    }

    return (
        <>
            <div className="Vpost-view-wrapper">
            <br/>
            <div className='post-right'>
                <BsFillEyeFill className='Vicons'/>
                <label>&nbsp;조회 :&nbsp;{datas.views}</label>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <AiFillLike className='Vicons'/>
                <label>&nbsp;추천 :&nbsp;{RecNum}</label>
            </div>
            <div className='post-left'>
                <BsFillPersonFill className='Vicons'/>
                <label>&nbsp;&nbsp;작성자 :&nbsp;&nbsp;{datas.name}</label>
            </div>
            <div className ="Vtitle">
                <label>{datas.title}</label>
            </div>

            <div className='Vbtn-left'>
                <Button onClick={(e) => navigate(-1)}
                    className="success-button"
                    variant="outlined">
                    목록으로 돌아가기
                </Button>
            </div>
                {(datas.mine ==true) ?
                    <div className="Vbtn-right">
                        <div>
                            {RecDisable==false &&Rcount ==1 ? (
                                <Button onClick={(e)=>{addRecommendations()}}
                                    className="success-button"
                                    variant="outlined">
                                    추천합니다</Button>) : (
                                <Button className="disable-button"
                                    variant="outlined"
                                    size="large">
                                    이미 추천을 했습니다😃</Button>)}
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           
                            <Button onClick={(e)=>navigate(`/talent/edit/${id}`)}
                                className="success-button"
                                variant="outlined">
                                수정하러 가기
                            </Button>
                        </div>
                    </div>
                        :
                    <div className='Vbtn-right'>
                        <div>
                            {RecDisable==false &&Rcount ==1 ? (
                               <Button onClick={(e)=>{addRecommendations()}}
                                 className="success-button"
                                  variant="outlined">
                                  추천합니다</Button>) : (
                                <Button className="disable-button"
                                    variant="outlined"
                                     size="large">
                                     이미 추천을 했습니다😃</Button>)}
                                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                            {JoinNum<MAXNUM && Participant==false ?(
                                <Button onClick={(e)=>{join()}}
                                        className="success-button"
                                        variant="outlined">
                                    참여합니다😃
                                </Button>) : JoinNum == MAXNUM && Participant==true ? (
                                <Button onClick={(e)=>goPage(id)}
                                        className="success-button"
                                        variant="outlined">
                                    완료
                                </Button>) : <Button onClick={(e)=>{join()}}
                                                     className="success-button"
                                                     variant="outlined">
                                참여할 수 없습니다
                            </Button>}
                        </div>
                    </div>
                }

                <br/><br/><br/>

                {datas!=null ? (
                    <>           
                                <div className='post-right'>
                                    <BsFillCalendarCheckFill className='Vicons'/>
                                    <label>&nbsp;&nbsp;작성일 :&nbsp;&nbsp;{datas.createdAt}</label>
                                </div>
                                
                            <div className='post-left'>
                            
                                <AiFillTag className='Vicons'/>
                                <label>&nbsp;&nbsp;카테고리 :&nbsp;&nbsp;{isCategory()}</label>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <AiFillAlert className='Vicons'/>
                                <label>&nbsp;&nbsp;긴급 여부 :&nbsp;&nbsp;{datas.emergency==true? <label>긴급</label> :<label>일반</label>}</label>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <BsFillGeoAltFill className='Vicons'/>
                                <label>&nbsp;&nbsp;장소 :&nbsp;&nbsp;{datas.errandAddress}</label>
                            </div>
                
                            <div className='post-right'>
                                <BsFillPersonPlusFill className='Vicons'/>
                                <label>&nbsp;&nbsp;현재 참여한 인원 :&nbsp;&nbsp;{JoinNum}&nbsp;&nbsp;</label> 
                                <label>/&nbsp;&nbsp;모집 인원 :&nbsp;&nbsp;{datas.maxPersonNum}</label>
                            </div>
                            <div className="post-left">
                                    <BsCoin className='Vicons' />
                                    <label>&nbsp; 가격 :&nbsp;{datas.price}원&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
                                </div>
                            <div className='Vcontent'>
                            <label>{datas.content}</label>
                            </div>
                            <div>
                                <div className='Vimage'>
                                    <img style={{
                                            width: "500px",
                                            height: "300px",
                                            margin: "10px 0 10px 40px",
                                            borderRadius: "0%",
                                            objectFit: "cover",
                                            border: "3px solid rgb(92, 143, 214)",
                                        }}
                                             src={`${process.env.PUBLIC_URL}/${img}`}
                                        /> 
                                </div>
                            </div>
                        </>
                    ) : <label style={{fontSize:'50px'}}>'해당 게시글을 찾을 수 없습니다.'</label>
                }
            </div>
        </>
    )
}

export default PostView;
