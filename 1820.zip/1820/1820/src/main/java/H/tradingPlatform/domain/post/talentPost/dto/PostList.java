package H.tradingPlatform.domain.post.talentPost.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PostList {

    private Long postId;
    private String name;
    private String title;
    private int price;
    private Long views;
    private boolean emergency;
    private String createdAt;
}
