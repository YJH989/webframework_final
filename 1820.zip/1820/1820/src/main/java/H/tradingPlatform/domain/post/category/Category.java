package H.tradingPlatform.domain.post.category;

import lombok.Getter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
public class Category {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "category_id")
    private Long categoryId;

    @Column(unique = true)
    private String name;

    @OneToMany(mappedBy = "category")
    private List<CategoryDetail> categoryDetails = new ArrayList<>();
}
