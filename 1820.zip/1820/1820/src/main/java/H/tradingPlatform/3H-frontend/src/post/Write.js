import React, { useEffect,useRef ,useState,useCallback} from "react";
import 'react-quill/dist/quill.snow.css'
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css'
import moment from 'moment';
import { Link, useNavigate } from 'react-router-dom';
import axios from "axios";
import {Button} from "@mui/material";
import './postCss/write.scss'
import getCookie from '../hooks/getCookie';
import FormControl from '@mui/material/FormControl';
import NativeSelect from '@mui/material/NativeSelect';

let completeDate;
let createDate;

const SERVER_URL = require("../test");

const Write=()=>{
    const [RadioValue,setRadioValue] = useState(false); //라디오 버튼 Value 저장
    const [Title,setTitle] = useState(''); //제목 저장
    const [Content, setContent] = useState(''); //내용 저장
    const [useValue,setUseValue] = useState(new Date()); //선택한 날짜 저장
    const [Price,setPrice] = useState(); //가격 저장
    const [Location,setLocation] = useState(''); //장소 저장
    const [maxPerson,setMaxperson] = useState() //참여 인원 저장
    const navigate = useNavigate();    
    const [imgInfo, setimgInfo] = useState({
        file: [],
    });

    const handleInputChange = (event) => {
        setimgInfo({
            file: event.target.files[0],
            filepreview: URL.createObjectURL(event.target.files[0]),
        })
    }
    //모든 정보 입력해야 제출 가능
    const canSubmit =useCallback(()=>{
        return Title !=="" && Content !=="" && Price !==""  &&Location !==""&& maxPerson !==""&&imgInfo.file.length !==0   ;
    },[Title,Content,Price,Location,maxPerson,imgInfo.file]);
    const handleSubmit = async()=>{
            createDate=moment(createTime).format("YYYY-MM-DD HH:mm")

            const formData = new FormData();
            formData.append('file', imgInfo.file);
            formData.append('title', Title);
            formData.append('content', Content);
            formData.append('completionTime',completeDate);
            formData.append('emergency', RadioValue);
            formData.append('errandAddress', Location);
            formData.append('maxPersonNum', maxPerson);
            formData.append('price', Price);
            formData.append('categoryDetailId', Category);

            await axios({
                method: "post",
                url: SERVER_URL.test()+"talent/post",
                data: formData,
                headers: {
                  'Content-Type': 'multipart/form-data',
                  Authorization: `Bearer${getCookie('id')}`
                },
              })
            .then((response) => {
                window.alert("등록이 완료 되었습니다");
                navigate("/talents");
        })
       
    };
    const [Category, setCategory] = useState(1);

    const onChangeC=(e)=>{
        setCategory(e.target.value)
    }

    const [completeTime,setCompleteTime] = useState(); //선택한 날짜 저장
    const [createTime,setCreateTime] = useState(); //선택한 날짜 저장
    useEffect(()=>{
        setCompleteTime(moment(useValue).format("YYYY-MM-DD HH:mm"))
    },[useValue])
    completeDate=completeTime

    return(
        <>


            <div className="write-wrapper">

                <div className="mt-3 font-semibold text-3xl" style={{color: "gray"}}>&nbsp;&nbsp;&nbsp;[ 게시글 작성하기 ]</div>
                <div className="flex justify-end ...">
                <div className="submitButton">
                {canSubmit() ? (
                    <Button onClick={handleSubmit}
                        className="success-button"
                        variant="outlined">
                        등록하기😃
                    </Button>) : (
                    <Button
                        className="disable-button"
                        variant="outlined"
                        size="large">
                        내용을 모두 입력하세요😭
                    </Button>
                    )}
                </div>
                </div>
                <div className="write-body">
                    <div className="text-wrapper">
                        <input type="text"
                               placeholder="제목을 입력하세요"
                               onChange={(e) => { setTitle(e.target.value); } }
                               value={Title}
                               className="title" />
                        <div className="emergency">
                        <div className="emergency  mb-2">
                            
                            <p className="font-semibold text-1xl mr-10" style={{color:"black"}}>긴급 여부 선택</p><br/>
                            <div className="radio_button">
                            <input type = "radio" value={true}
                                       onChange={(e)=>{setRadioValue(e.target.value)}}
                                       checked = {String(RadioValue)==="true"}/>
                                <label className=" label">긴급</label>
                                <input type = "radio" value={false}
                                       onChange={(e)=>{setRadioValue(e.target.value)}}
                                       checked = {String(RadioValue)==="false"}/>
                                <label className=" label">일반</label>
                            </div>
                        </div>
                        <p className=" ml-20 font-semibold text-1xl" style={{color:"black"}}>카테고리</p><br/>
                        <div class="ml-10 mt-3">
                        <FormControl>
                        <NativeSelect onChange={onChangeC} value={Category}>
                                <option value="1">뷰티</option>
                                <option value="2">스포츠</option>
                                <option value="3">외국어</option>
                                <option value="4">프로그래밍</option>
                                <option value="5">운동</option>
                                <option value="6">악기</option>
                                <option value="7">기타</option>
                            </NativeSelect>
                        </FormControl><br/><br/>
                        </div>
                        </div>


                        <input type="text"
                               placeholder="가격을 입력하세요(정수만 입력 가능)"
                               onChange={(e) => { setPrice(e.target.value.replace(/[^0-9]/g, "")); } }
                               value={Price}
                               className="title" />
                        <input type="text"
                               placeholder="위치를 입력하세요"
                               onChange={(e) => { setLocation(e.target.value); } }
                               value={Location}
                               className="title" />
                        <input type="text"
                               placeholder="참여 인원을 입력하세요(정수만 입력 가능)"
                               onChange={(e) => { setMaxperson(e.target.value.replace(/[^0-9]/g, "")); } }
                               value={maxPerson}
                               className="title" />
                        <div class = "mt-5">
                        <div className="emergency">
                        <div class="block">
                            <div class="justify-items-center">
                            <div className="emergency">[ 날짜를 선택해주세요 ]</div>
                            </div>
                            <div >
                                <Calendar onChange={setUseValue} value={useValue} />
                            </div>
                            <div className="text-gray-500 mt-4">
                                <p>현재 선택한 날짜:{moment(useValue).format("YYYY-MM-DD")}</p>
                            </div>
                        </div>
                            <div class="block ml-60 mt-1">
                            <div className="emergency mr-20">[ 이미지 업로드 ]</div>
                            {imgInfo.filepreview !== null ?
                                <img style={{
                                    width: "405px",
                                    height: "271px",
                                    objectFit: "cover",
                                    //border: "0.01px solid lightgray",
                                }}
                                     src={imgInfo.filepreview}
                                /> : null}
                            <input type="file" id="profileImage"
                                   className="form-control" name="upload_file"
                                   onChange={handleInputChange}/>
                            </div>
                            </div>
                            </div>
                    <div class="mt-10">
                    <textarea
                        onChange={(e) => {
                            setContent(e.target.value);
                        } }
                        className="content"
                        placeholder="내용을 입력하세요"
                        value={Content} />
                    </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Write;