import React from 'react';
import SidebarMainPage from './components/SidebarMainPage';

function App() {
  return (
    <SidebarMainPage />
  );
}

export default App;
