import React from 'react';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import { Link } from 'react-router-dom';
import CommonTableColumn from './CommonTableColumn';
import CommonTableRow from './CommonTableRow';


 const Customer=({postId,title,price,name,emergency,views,createdAt})=>{
     //console.log({index},{postId},{price},{title},{name},{createdAt},{recommendations},{views})
     return(
         <>
         <CommonTableRow key={postId} event={postId} >
           <CommonTableColumn>{ postId }</CommonTableColumn>
           <CommonTableColumn>{ title }</CommonTableColumn>
             <CommonTableColumn>{ name }</CommonTableColumn>
           <CommonTableColumn>{ price }</CommonTableColumn>
           <CommonTableColumn>{ emergency }</CommonTableColumn>
           <CommonTableColumn>{ views }</CommonTableColumn>
           <CommonTableColumn>{ createdAt }</CommonTableColumn>
         </CommonTableRow>
         </>
     )
 }

export default Customer;