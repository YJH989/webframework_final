import { FaStar } from "react-icons/fa";

const Star = ({ selected = false, onSelect = f => f }) => (
    <FaStar
        size='50'
        color={selected ? "#fcc419" : "grey"}
        onClick={onSelect}
    />
);

export default Star;

