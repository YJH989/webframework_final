import React from 'react';
//import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter, Route, Routes} from "react-router-dom"; // eslint-disable-line no-unused-vars
import Sidebar from './SidebarMain.jsx';
import Mypage from "../myPage/Mypage.js";
import Login from "../pages/Login.js";
import MemberDataUpdate from "../myPage/MemberDataUpdate";
import Comment from "../comment/Comment.js";
import PostComment from "../comment/PostComment.js";
import Signup from '../pages/Signup.js';
import Board from '../post/Board.js';
import Write from '../post/Write.js';
import PostView from '../post/PostView.js';
import Main from '../pages/Main.js';
import Edit from '../post/Edit.js';
import NotFound from '../pages/NotFound.js';

function SidebarPage() {
  return (
    <BrowserRouter>
    <Sidebar>
    <Routes>      
        <Route path="/" element={<Main />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/talents" element={<Board />} />
        <Route path="/talent/detail/:id" element={<PostView />} />
        <Route path="/talents/write" element={<Write />} />
        <Route path="/talent/edit/:id" element={<Edit />} />
        <Route path="/mypage" element={<Mypage />} />
        <Route exact path="/memberdataupdate" element={<MemberDataUpdate />} />
        <Route exact path="/comment" element={<Comment />} />
        <Route exact path="/postcomment/:postId" element={<PostComment />} />
        <Route path ="*" element={<NotFound />}/>
    </Routes>
    </Sidebar>   
    </BrowserRouter>
    
  );
}

export default SidebarPage;