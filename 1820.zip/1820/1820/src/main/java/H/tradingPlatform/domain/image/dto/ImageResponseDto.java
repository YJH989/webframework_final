package H.tradingPlatform.domain.image.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ImageResponseDto {

    private Long imageId;
    private String fullPath;
    private String message;
}
