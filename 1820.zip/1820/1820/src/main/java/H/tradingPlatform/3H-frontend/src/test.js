var exports = module.exports = {};
exports.test = function() {
    return "http://localhost:8080/";
}