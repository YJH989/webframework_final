package H.tradingPlatform.domain.post.talentPost.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TalentPostsListResponseDto {

    private String name;
    private Long postId;
    private String title;
    private Long views;
    private boolean emergency;
    private String createdAt;
    private int price;
}
