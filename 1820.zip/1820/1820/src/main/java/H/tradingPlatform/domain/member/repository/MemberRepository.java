package H.tradingPlatform.domain.member.repository;

import H.tradingPlatform.domain.member.Member;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MemberRepository extends JpaRepository<Member, String> {

        Member findByLoginId(String loginId);
}
