import React from "react";

export const Notfound = () => {

    return (
        <div>
            <p className="mt-3 font-semibold text-3xl" style={{color: "gray"}}>&nbsp;&nbsp;&nbsp;[ Not Found Page ]</p>
        </div>
    );
};

export default Notfound;