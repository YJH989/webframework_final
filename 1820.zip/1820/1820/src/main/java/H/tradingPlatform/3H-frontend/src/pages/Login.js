import {useEffect, useState} from "react";
import axios from 'axios';
import TextField from '@mui/material/TextField';
import Checkbox from '@mui/material/Checkbox';
import Button from '@mui/material/Button';
import FormControlLabel from '@mui/material/FormControlLabel';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import setCookie from '../hooks/setCookie';


var SERVER_URL = require("../test");

function Login() {

    const [value, setValue] = useState("")

    const onChange = (event) => {
        setValue(event.currentTarget.value)
    }

    const validation = () => {
        let check = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,20}/;
        return check.test(value);
    }


    const onSubmitHandler = async (e) => {
        e.preventDefault();
        const loginId = e.target.Id.value;
        const password = e.target.password.value;

        await axios.post(SERVER_URL.test() + "login", {loginId, password}) //정보 일치 시 response로 토큰을 받는다
            .then((response) => {
                if (response.data.status === 200) {
                    document.location.href = '/';
                    setCookie('id', JSON.stringify(response.data.data.accessToken));
                } else if (response.data.status === 400) {
                    if (response.data.data[0].message != null) {
                        alert(response.data.data[0].message);
                    }
                    if (response.data.data[1].message != null) {
                        alert(response.data.data[1].message);
                    }
                }
            })
            .catch((e) => {
                return alert("이메일 혹은 비밀번호를 확인하세요.");
            });

    };

    return (

        <Container compenent="main" maxWidth="xs">
            <Box
                sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}
            >
                <Avatar sx={{m: 1, bgcolor: 'secondary.main'}}>
                    <LockOutlinedIcon/>
                </Avatar>
                <Typography component="h1" variant="h5">
                    Sign in
                </Typography>
            </Box>
            <form onSubmit={onSubmitHandler}>

                <TextField
                    margin="normal"
                    label="ID(최대 20자리)"
                    required fullWidth
                    name="Id"
                    // autoComplete="email"
                    inputProps={{maxLength: 20}}
                />
                <br></br>
                <TextField
                    margin="normal"
                    label="password"
                    type="password" required fullWidth
                    name="password"
                    autoComplete="current-password"
                    value={value}
                    onChange={onChange}
                    error={!validation()}
                    helperText={validation() ? "" : "8~20자리 대소문자 숫자 특수문자를 입력하라굿~ 훗"}
                />
                <br></br>
                <Button type="submit" fullWidth variant="contained"
                        sx={{mt: 3, mb: 2}}>
                    Sign in
                </Button>
                <Grid container>

                    <Grid item>
                        <Link href="/signup">Sign Up</Link>
                    </Grid>
                </Grid>
            </form>

        </Container>

    );
}


export default Login;