package H.tradingPlatform.domain.post.talentPost.repository;

import H.tradingPlatform.domain.member.JoinMembers;
import H.tradingPlatform.domain.post.talentPost.TalentPost;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class TalentPostRepository {

    private final EntityManager em;

    public List<TalentPost> findAll(int offset, int limit){
        return em.createQuery(
                "select t from TalentPost t"+
                        " join fetch t.member m order by t.dateTime.createdAt desc", TalentPost.class)
                .setFirstResult(offset)
                .setMaxResults(limit)
                .getResultList();
    }

    public TalentPost findOne(Long postId){
        return em.find(TalentPost.class, postId);
    }

    public List<TalentPost> findByMemberId(Long memberId,int offset, int limit){
        return em.createQuery(
                "select t from TalentPost t"+
                        " join fetch t.member m where m.memberId = :memberId order by t.dateTime.createdAt desc",TalentPost.class)
                .setParameter("memberId", memberId)
                .setFirstResult(offset)
                .setMaxResults(limit)
                .getResultList();
    }

    public Long saveJoinMember(JoinMembers joinMembers){
        em.persist(joinMembers);
        return joinMembers.getJoinMembersId();
    }

    public TalentPost save(TalentPost talentPost){
        em.persist(talentPost);
        return talentPost;
    }
}