package H.tradingPlatform.domain.starPoint.controller;

import H.tradingPlatform.ResponseResult;
import H.tradingPlatform.domain.starPoint.dto.CommentAndStarPointEvaluation;
import H.tradingPlatform.domain.starPoint.service.StarPointService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

@RestController
@RequiredArgsConstructor
public class StarPointController {

    public final StarPointService starPointService;

    @PostMapping("/evaluation")
    public ResponseResult evaluation(ServletRequest request, @RequestBody CommentAndStarPointEvaluation commentAndStarPointEvaluation){
        return starPointService.commentAndStarPoint(request, commentAndStarPointEvaluation);
    }

    @GetMapping("/evaluation")
    public ResponseResult searchEvaluation(
            ServletRequest request,
            @RequestParam("offset")int offset,
            @RequestParam("limit")int limit){

        return starPointService.searchEvaluation(request,offset,limit);
    }
}