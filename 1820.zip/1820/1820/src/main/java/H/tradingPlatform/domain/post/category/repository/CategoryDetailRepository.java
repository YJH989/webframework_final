package H.tradingPlatform.domain.post.category.repository;

import H.tradingPlatform.domain.member.Member;
import H.tradingPlatform.domain.post.category.CategoryDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryDetailRepository extends JpaRepository<CategoryDetail, Long> {

    CategoryDetail findByCategoryDetailId(Long categoryDetailId);
}
