import React, {useEffect, useState} from "react";
import Button2 from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Customer from '../components/table/Customer';
import Box from '@material-ui/core/Box';
import axios, {toFormData} from "axios";
import getCookie from '../hooks/getCookie';
import Pagination from '../components/table/Pagination';
import removeCookie from '../hooks/removeCookie';
import '../comment/commentCss/Comment.css';
import './myPageCss/Mypage.css';
import CommonTable from '../components/table/CommonTable'

var SERVER_URL = require("../test");

const Mypage = () => {
    const [user, setUserInfo] = useState({});
    const [posts, setPosts] = useState([]);// 내가 쓴 게시글 저장하는 상태변수

    const [limit, setLimit] = useState(3); // 한 페이지 당 게시글 몇 개씩 보여줄지
    const [page, setPage] = useState(1);  //현제 페이지 번호 = 1번
    const offset = (page - 1) * limit;

    const [len, setLen] = useState(0);


    useEffect(() => {
        const fetchMyPageData = async () => {
            //"members/self"
            const response = await axios.get(SERVER_URL.test() + 'members/self', {
                params: {"offset": offset, "limit": limit},
                headers: {
                    Authorization: `Bearer${getCookie('id')}`,
                },
            })
            setUserInfo(response.data.data.userInfo);
            setPosts(response.data.data.postList);
            await setLen(response.data.data.postList.length)
        };
        fetchMyPageData();
    }, [offset]);


    const handleChange = (e, p) => {
        setPage(p);
    }

    const onClick = () => {
        onClickHandler();
    }
    const onClickHandler = async () => {
        axios({
            method: 'patch',
            url: SERVER_URL.test() + "members/quit",
            headers: {Authorization: `Bearer${getCookie('id')}`}
        })
            .then((response) => {
                if (response.data.status === 201) {
                    removeCookie('id');
                    alert(response.data.data.memberId + "님은" + response.data.data.message);
                    document.location.href = '/';
                }
            })
    };

    const [imgInfo, setimgInfo] = useState({
        file: [],
    });

    const handleInputChange = (event) => {
        setimgInfo({
            file: event.target.files[0],
            filepreview: URL.createObjectURL(event.target.files[0]),
        })
    }

    const submit = async () => {

        const formData = new FormData();

        formData.append('file', imgInfo.file);

        await axios.post(SERVER_URL.test() + "members/upload", formData, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer${getCookie('id')}`
            }
        })
            .then((response) => {
                alert(response.data.data.message)
                window.alert("사진 용량이 너무 클 경우 변경사항이 제대로 반영되지 않을 수 있습니다.");
            })

    }

    return (
        <React.Fragment>
            <section>
                <div class="float-right">
                    <Button2 fullWidth sx={{mt: 3, mb: 2}} style={{color: "#9B111E"}} onClick={onClick}>
                        withdraw
                    </Button2>
                </div>
                <div>
                    <p className="mt-3 font-semibold text-3xl" style={{color: "gray"}}>&nbsp;&nbsp;&nbsp;[ 마이페이지 ]</p>
                    <br/>
                </div>


                <div>
                    <div className='profile_img text-center p-4' style={{backgroundcolor: "lightgray"}}>
                        <div className='flex flex-column justify-content-center align-items-center'>

                            <hr></hr>
                            <br/>
                            <br/>
                            <form className="container">
                                <div>
                                    {imgInfo.filepreview !== null ?
                                        <img style={{
                                            width: "200px",
                                            height: "200px",
                                            borderRadius: "50%",
                                            objectFit: "cover",
                                            border: "4px solid green",
                                        }}
                                             src={user.image}
                                        /> :
                                        <img style={{
                                            width: "200px",
                                            height: "200px",
                                            borderRadius: "50%",
                                            objectFit: "cover",
                                            border: "4px solid green",
                                        }}
                                             src={user.image}
                                        />}


                                    <input type="file" id="profileImage" className="form-control" name="upload_file"
                                           onChange={handleInputChange}/>

                                    <button type="submit" className="btn btn-dark" onClick={() => submit()}>Save
                                    </button>
                                </div>

                                <Box class="center">
                                    {/* <br/><br/>홍길동 */}
                                    &nbsp;<br/><TextField
                                    fullWidth
                                    name="Id"
                                    // autoComplete="email"
                                    inputProps={{maxLength: 20}}
                                    value={user.name} //user.name
                                    size="medium"
                                />
                                    &nbsp;<TextField
                                    fullWidth
                                    name="email"
                                    // autoComplete="email"
                                    inputProps={{maxLength: 20}}
                                    value={user.email}
                                    size="medium"
                                />

                                    &nbsp;<TextField
                                    fullWidth
                                    name="gender"
                                    inputProps={{maxLength: 20}}
                                    value={user.gender}
                                />


                                </Box>
                            </form>
                        </div>

                        <br/>
                        <hr></hr>
                    </div>

                    <p className="mt-3 font-semibold text-1xl" style={{color: "gray"}}>내가 작성한 게시글</p><br/>


                    <CommonTable headersName={['번호', '제목', '이름', '가격', '긴급여부', '조회수', '등록일']}>

                        {/* data.map */}
                        {Array.isArray(posts) ?
                            posts.map(c => {
                                return (<Customer
                                        key={c.postId}
                                        postId={c.postId}
                                        title={c.title}
                                        name={c.name}
                                        price={c.price}
                                        emergency={c.emergency ? "긴급여부O" : "긴급여부X"}
                                        views={c.views}
                                        createdAt={c.createdAt}
                                    />
                                );
                            })
                            : null
                        }
                    </CommonTable>
                    <br/>

                    <Pagination className="Column" total={len} limit={limit} page={page} setPage={setPage}>
                    </Pagination>
                </div>
            </section>
        </React.Fragment>

    )
}

export default Mypage;