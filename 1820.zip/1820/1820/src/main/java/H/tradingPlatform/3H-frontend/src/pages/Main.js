import "./pagesCss/main.scss";

const Main = () => {
  return (
    <div className="main-wrapper">
      <div className="main-title">
        <span>1820</span>에 오신걸 환영합니다
      </div>
      <div className="main-contents">
        이 사이트는 여러분의 니즈를 충족시켜드립니다🎁<br/>
        재능을 교환하며 여러분의 포인트를 채워보세요👍
      </div>
      <div className="about-project">
        이 프로젝트는 웹프레임워크7반 2조가 <br/>
        <span>React</span>와
        <span> Spring boot</span>로 만들었습니다😊
      </div>
      
    </div>
  )
}
export default Main;