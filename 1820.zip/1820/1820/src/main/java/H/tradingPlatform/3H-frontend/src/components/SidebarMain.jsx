import React, {useState, useEffect} from "react";
import {Nav} from 'react-bootstrap'
import './Sidebar.css';
import {FaBars} from 'react-icons/fa'
import {
    IoGift,
    IoSearchSharp,
    IoPersonSharp,
    IoPersonCircleSharp,
    IoChatboxEllipses,
    IoCaretDown,
    IoCaretUp
} from "react-icons/io5";
import "tailwindcss/tailwind.css";
import {Link, NavLink} from 'react-router-dom';
import Button from '@mui/material/Button';
import {createTheme, ThemeProvider} from '@mui/material/styles';
import getCookie from '../hooks/getCookie';
import axios from "axios";
import removeCookie from '../hooks/removeCookie';

var SERVER_URL = require("../test");

const Sidebar = ({children}) => {
    const [isOpen, setIsOpen] = useState(true);
    const toggle = () => setIsOpen(!isOpen);
    const [inputValue, setInputValue] = useState("");

    const [user, setUserInfo] = useState([]); //유저정보 저장하는 상태변수
    const [posts, setPosts] = useState([]); // 내가 쓴 게시글 저장하는 상태변수

    const [limit, setLimit] = useState(3); // 한 페이지 당 게시글 몇 개씩 보여줄지
    const [page, setPage] = useState(1);  //현제 페이지 번호 = 1번
    const offset = (page - 1) * limit;

    let usercookie = `Bearer${getCookie('id')}`;


    const onClick = () => {
        removeCookie('id');
        document.location.href = '/';
    }

    useEffect(() => {
        const fetchMyPageData = async () => {
            //"members/self"
            const response = await axios.get(SERVER_URL.test() + 'members/self', {
                params: {"offset": offset, "limit": limit},
                headers: {
                    Authorization: `Bearer${getCookie('id')}`,
                },
            })

            setUserInfo(response.data.data.userInfo);
            setPosts(response.data.data.postList);
        };
        fetchMyPageData();
    }, []);

    const [imgInfo, setimgInfo] = useState({
        file: [],
    });


    const theme = createTheme({ /*버튼 색상 설정 */
        palette: {
            info: {
                main: '#d3fffc',
            },
        },
    });

    const menuItemLogin = [
        {
            title: "로그인",
            path: "/Login"
        },
        {
            title: "회원가입",
            path: "/Signup"
        }
    ]
    const menuItemMain = [
        {
            title: "재능 팔아요",
            path: "/talents",
            icon: <IoGift/>
        }
    ]

    const menuItemMypage = [

        {
            title: "마이페이지",
            path: "/Mypage",
            icon: <IoPersonSharp/>,
            icondown: <IoCaretDown/>,
            iconup: <IoCaretUp/>
        },
        {
            title: "회원 정보 수정",
            path: "/MemberDataUpdate",
            icon: <IoPersonCircleSharp/>
        },
        {
            title: "나의 평점 확인",
            path: "/Comment",
            icon: <IoChatboxEllipses/>
        }
    ]

    return (


        <div className="container">

            <div style={{width: isOpen ? "250px" : "50px"}} className="sidebar">
                <div className="top_section">
                    <Link to={menuItemMain.path = "/"}> {/* 여기서 Link를 준 이유는 style지정을 안 주기 위함 */}
                        <div style={{display: isOpen ? "block" : "none"}} className="logo">1820</div>
                    </Link>
                    <div style={{marginLeft: isOpen ? "30px" : "0px"}} className="bars">
                        <FaBars onClick={toggle}/>
                    </div>
                </div>


                <div class="pb-8">

                    <form style={{display: isOpen ? "block" : "none"}}>
                        <div className="Searchbox" class="flex">
                            <input placeholder="검색어를 입력하세요."
                                   value={inputValue}
                                   onChange={(e) => setInputValue(e.target.value)}/> {/*e.target.value를 조회하면 현재 input의 value값을 알 수 있다.*/}
                            <button className="button2"><IoSearchSharp/></button>
                        </div>
                    </form>
                    <form style={{display: isOpen ? "block" : "none"}}><br/></form>

                </div>


                <div>
                    <Nav>
                        {
                            usercookie === "Bearerundefined" ? //usercookie가 없으면 재능게시판만 보여줘라. 있으면 다 보여줘라
                                <>
                                    <div className="button">
                                        <ThemeProvider theme={theme}>
                                            <Link
                                                to={menuItemLogin.path = "/login"}> {/* NavLink를 사용한 이유 : 링크가 활성화 되었을 때의 스타일값을 지정해줄 수가 있다해서 */}
                                                <Button style={{display: isOpen ? "block" : "none"}}
                                                        color="info">로그인</Button>
                                            </Link>
                                            <Link to={menuItemLogin.path = "/signup"}>
                                                <Button style={{display: isOpen ? "block" : "none"}}
                                                        color="info">회원가입</Button>
                                            </Link>
                                        </ThemeProvider>
                                    </div>


                                    <div>

                                        {
                                            menuItemMain.map((item, index) => (
                                                <NavLink to={item.path} key={index} className="link"
                                                         activeclassName="active">
                                                    <div className="icon">{item.icon}</div>
                                                    <div style={{display: isOpen ? "block" : "none"}}
                                                         className="link_text">{item.title}</div>
                                                </NavLink>
                                            ))
                                        }
                                    </div>
                                </>
                                :
                                <>
                                    <div className="logout">
                                        <div class="mr-2">
                                            <Link to={menuItemMypage.path = "/Mypage"}>
                                                {imgInfo.filepreview !== null ?
                                                    <img style={{
                                                        width: "40px",
                                                        height: "40px",
                                                        borderRadius: "50%",
                                                        objectFit: "cover",
                                                        border: "1px solid gray",
                                                    }}
                                                         src={user.image}
                                                    /> :
                                                    <img style={{
                                                        width: "40px",
                                                        height: "40px",
                                                        borderRadius: "50%",
                                                        objectFit: "cover",
                                                        border: "1px solid gray",
                                                    }}
                                                         src={user.image}
                                                    />}
                                            </Link>
                                        </div>
                                        <div className="py-4">
                                            <Link to={menuItemMypage.path = "/Mypage"}>
                                                <div class="pl-2 pr-2 flex flex-row ... "
                                                     style={{display: isOpen ? "block" : "none"}}>{user.name} </div>
                                            </Link>
                                        </div>
                                        <div className="py-12">
                                            <ThemeProvider theme={theme}>
                                                <Button style={{display: isOpen ? "block" : "none"}} color="info"
                                                        onClick={onClick}>로그아웃</Button>
                                            </ThemeProvider>
                                        </div>

                                    </div>
                                    {
                                        menuItemMain.map((item, index) => (
                                            <NavLink to={item.path} key={index} className="link"
                                                     activeclassName="active">
                                                <div className="icon">{item.icon}</div>
                                                <div style={{display: isOpen ? "block" : "none"}}
                                                     className="link_text">{item.title}</div>
                                            </NavLink>
                                        ))
                                    }
                                    {
                                        menuItemMypage.map((item, index) => (
                                            <NavLink to={item.path} key={index} className="link"
                                                     activeclassName="active">
                                                <div className="icon">{item.icon}</div>
                                                <div style={{display: isOpen ? "block" : "none"}}
                                                     className="link_text">{item.title}</div>
                                            </NavLink>
                                        ))
                                    }
                                </>
                        }
                    </Nav>
                </div>
            </div>
            {/* 사이드바 끝 */}
            <main className="maincontent">{children}</main>
            {/* 글 내용 받아옴 */}
        </div>
    );
};

export default Sidebar
