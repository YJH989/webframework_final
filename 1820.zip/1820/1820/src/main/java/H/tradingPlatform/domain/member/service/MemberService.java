package H.tradingPlatform.domain.member.service;

import H.tradingPlatform.ResponseResult;
import H.tradingPlatform.authentication.JwtTokenProvider;
import H.tradingPlatform.authentication.dto.TokenInfo;
import H.tradingPlatform.domain.DateTime;
import H.tradingPlatform.domain.image.repository.ImageRepository;
import H.tradingPlatform.domain.member.Member;
import H.tradingPlatform.domain.member.MemberGender;
import H.tradingPlatform.domain.member.dto.*;
import H.tradingPlatform.domain.member.repository.MemberRepository;
import H.tradingPlatform.domain.post.talentPost.TalentPost;
import H.tradingPlatform.domain.post.talentPost.dto.PostList;
import H.tradingPlatform.domain.post.talentPost.repository.TalentPostRepository;
import H.tradingPlatform.exception.dto.ErrorResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static H.tradingPlatform.authentication.filter.JwtAuthenticationFilter.resolveToken;

@Service
@Transactional
@RequiredArgsConstructor
public class MemberService {
    private final MemberRepository memberRepository;
    private final AuthenticationManagerBuilder authenticationManagerBuilder;
    private final JwtTokenProvider jwtTokenProvider;
    private final TalentPostRepository talentPostRepository;
    private final PasswordEncoder passwordEncoder;

    public ResponseResult join(JoinRequestDto joinRequestDto) {
        String errorMessage = validateDuplicateMember(joinRequestDto);//중복 회원 검증
        List<String> roles = new ArrayList<String>();
        roles.add("USER");
        Member member = Member.builder()
                .loginId(joinRequestDto.getLoginId())
                .password(passwordEncoder.encode(joinRequestDto.getPassword()))
                .studentId(joinRequestDto.getStudentId())
                .name(joinRequestDto.getName())
                .gender(MemberGender.from(joinRequestDto.getGender()))
                .email(joinRequestDto.getEmail())
                .roles(roles)
                .birthDate(joinRequestDto.getBirthDate())
                .dateTime(new DateTime(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),null,null))
                .build();

        if(errorMessage == ""){
            memberRepository.save(member);
            JoinResponseDto joinResponseDto = new JoinResponseDto(member.getLoginId());
            return new ResponseResult(HttpStatus.CREATED.value(), joinResponseDto);
        }else {
            ErrorResponseDto errorResponseDto = new ErrorResponseDto(errorMessage);
            return new ResponseResult(HttpStatus.BAD_REQUEST.value(),errorResponseDto);
        }
    }

    private String validateDuplicateMember(JoinRequestDto joinRequestDto) {
        Member findMembers = memberRepository.findByLoginId(joinRequestDto.getLoginId());
        if (findMembers != null) {
            return "이미 존재하는 회원입니다";
        }else{
            return "";
        }
    }

    public ResponseResult login(String loginId, String password) {
        Member findMember = memberRepository.findByLoginId(loginId);
        if(findMember.getDateTime().getCanceledAt() != null){
            ErrorResponseDto errorResponseDto = new ErrorResponseDto("존재하지 않거나 탈퇴한 회원입니다.");
            return new ResponseResult(HttpStatus.BAD_REQUEST.value(), errorResponseDto);
        }else{
            // 1. Login ID/PW 를 기반으로 Authentication 객체 생성
            // 이때 authentication 는 인증 여부를 확인하는 authenticated 값이 false
            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(loginId, password);
            // 2. 실제 검증 (사용자 비밀번호 체크)이 이루어지는 부분
            // authenticate 매서드가 실행될 때 CustomUserDetailsService 에서 만든 loadUserByUsername 메서드가 실행
            Authentication authentication = authenticationManagerBuilder.getObject().authenticate(authenticationToken);
            // 3. 인증 정보를 기반으로 JWT 토큰 생성
            TokenInfo tokenInfo = jwtTokenProvider.generateToken(authentication);

            return new ResponseResult(HttpStatus.OK.value(), tokenInfo);
        }
    }

    public ResponseResult MemberPage(ServletRequest request,int offset, int limit){

        String token = resolveToken((HttpServletRequest) request);
        String loginId = "";
        // 2. validateToken 으로 토큰 유효성 검사
        if (token != null && jwtTokenProvider.validateToken(token)) {
            // 토큰이 유효할 경우 토큰에서 Authentication 객체를 가지고 와서 SecurityContext 에 저장
            Authentication authentication = jwtTokenProvider.getAuthentication(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loginId = authentication.getName();
        }
        if(loginId == ""){
            ErrorResponseDto errorResponseDto = new ErrorResponseDto("잘못된 토큰입니다. 재로그인 후 이용해주세요.");
            return new ResponseResult(HttpStatus.FORBIDDEN.value(),errorResponseDto);
        }else{
            Member findMember = memberRepository.findByLoginId(loginId);
            if (findMember.getProfileImage() != null){
                String[] imageUrlSplit = findMember.getProfileImage().getImageUrl().split("\\\\");
                    String imageUrl = imageUrlSplit[imageUrlSplit.length - 2] + "\\" + imageUrlSplit[imageUrlSplit.length - 1];
                    UserInfo userInfo = new UserInfo(findMember.getName(), findMember.getEmail(),
                            findMember.getGender(), imageUrl);
                    List<TalentPost> findPosts = talentPostRepository.findByMemberId(findMember.getMemberId(), offset, limit);
                    List<PostList> collect = findPosts.stream()
                            .map(m -> new PostList(m.getPostId(), findMember.getName(), m.getTitle(),
                                    m.getPrice(), m.getViews(), m.isEmergency(), m.getDateTime().getCreatedAt()))
                            .collect(Collectors.toList());

                    MemberPage memberPage = new MemberPage(userInfo, collect);

                    return new ResponseResult(HttpStatus.OK.value(), memberPage);
            }else{
                UserInfo userInfo = new UserInfo(findMember.getName(),findMember.getEmail(),
                        findMember.getGender(), null);
                List<TalentPost> findPosts = talentPostRepository.findByMemberId(findMember.getMemberId(), offset, limit);
                List<PostList> collect = findPosts.stream()
                        .map(m -> new PostList(m.getPostId(),findMember.getName(),m.getTitle(),
                                m.getPrice(), m.getViews(), m.isEmergency(),m.getDateTime().getCreatedAt()))
                        .collect(Collectors.toList());

                MemberPage memberPage = new MemberPage(userInfo,collect);

                return new ResponseResult(HttpStatus.OK.value(), memberPage);
            }
        }
    }

    public ResponseResult quit(ServletRequest request){
        String token = resolveToken((HttpServletRequest) request);
        String loginId = "";
        // 2. validateToken 으로 토큰 유효성 검사
        if (token != null && jwtTokenProvider.validateToken(token)) {
            // 토큰이 유효할 경우 토큰에서 Authentication 객체를 가지고 와서 SecurityContext 에 저장
            Authentication authentication = jwtTokenProvider.getAuthentication(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loginId = authentication.getName();
        }
        if(loginId == ""){
            ErrorResponseDto errorResponseDto = new ErrorResponseDto("잘못된 토큰입니다. 재로그인 후 이용해주세요.");
            return new ResponseResult(HttpStatus.FORBIDDEN.value(),errorResponseDto);
        }else {
            Member findMember = memberRepository.findByLoginId(loginId);

            findMember.getDateTime().canceledAtUpdate();

            MemberQuitAndEditDto memberQuitAndEditDto = new MemberQuitAndEditDto(findMember.getMemberId(), "탈퇴 되었습니다.");

            return new ResponseResult(HttpStatus.CREATED.value(), memberQuitAndEditDto);
        }
    }

    public ResponseResult edit(ServletRequest request, MemberGender gender, String name, String password){

        String token = resolveToken((HttpServletRequest) request);
        String loginId = "";
        // 2. validateToken 으로 토큰 유효성 검사
        if (token != null && jwtTokenProvider.validateToken(token)) {
            // 토큰이 유효할 경우 토큰에서 Authentication 객체를 가지고 와서 SecurityContext 에 저장
            Authentication authentication = jwtTokenProvider.getAuthentication(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loginId = authentication.getName();
        }
        if(loginId == ""){
            ErrorResponseDto errorResponseDto = new ErrorResponseDto("잘못된 토큰입니다. 재로그인 후 이용해주세요.");
            return new ResponseResult(HttpStatus.FORBIDDEN.value(),errorResponseDto);
        }else{
            Member findMember = memberRepository.findByLoginId(loginId);
            findMember.updatePassword(passwordEncoder.encode(password));
            findMember.updateGender(gender);
            findMember.updateName(name);
            findMember.getDateTime().updatedAtUpdate();

            MemberQuitAndEditDto memberQuitAndEditDto = new MemberQuitAndEditDto(findMember.getMemberId(), "수정 되었습니다.");

            return new ResponseResult(HttpStatus.CREATED.value(), memberQuitAndEditDto);
        }
    }
}
