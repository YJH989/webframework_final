import React, { useEffect, useState } from "react";
import axios from 'axios';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import FormControl from '@mui/material/FormControl';
import NativeSelect from '@mui/material/NativeSelect';
import getCookie from '../hooks/getCookie';

var SERVER_URL = require("../test");

const MemberDataUpdate= () => {
    const [value, setValue] = useState("");

    const validation =()=>{
        let check = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,20}/;
        return check.test(value);
      }
    const onChange = (event) => {
       setValue(event.currentTarget.value)
    }

    const onSubmitHandler = async (e) => {
        e.preventDefault();
        const name = e.target.name.value;
        const password = e.target.password.value;
        const gender = e.target.gender.value;


        const data = {
            "name" : name,
            "password" : password,
            "gender" : gender,
        }

        axios({method: 'patch', url: SERVER_URL.test() + "members/edit", data, headers: {Authorization: `Bearer${getCookie('id')}`}})

            .then((response) => {
                if(response.data.status === 201) {
                    alert(response.data.data.message);
                    document.location.href = '/Mypage';
                }
            })
        .catch((e) => {
            return alert("정보수정실패.");
        });
    };

    return (
        <React.Fragment>
            <section>
            <p className="mt-3 font-semibold text-2xl" style={{color:"gray"}}>회원정보 수정</p><br/>

            <form onSubmit={onSubmitHandler}>
            <p className="mt-3 font-semibold text-1xl" style={{color:"gray"}}>성별</p><br/>
                <FormControl>
                    <NativeSelect defaultValue={30} name="gender">
                        <option value="MALE">MALE</option>
                        <option value="FEMALE">FEMALE</option>
                    </NativeSelect>
                </FormControl><br/><br/>

                <p className="mt-3 font-semibold text-1xl" style={{color:"gray"}}>이름</p>
                <TextField 
                margin="normal" 
                label="name" 
                required fullWidth 
                name="name"
                inputProps = {{ maxLength : 20}}
                /><br></br><br/>

                <p className="mt-3 font-semibold text-1xl" style={{color:"gray"}}>비밀번호</p>
                <TextField  
                margin="normal" 
                label="password" 
                type="password" required fullWidth 
                name="password" 
                autoComplete="current-password"
                value={value}
                onChange={onChange}
                error={!validation()}
                helperText={validation() ? "":"8~20자리 대소문자 숫자 특수문자를 입력하라굿~ 훗"}
                />
                <br></br><br/>

                <Button type="submit" fullWidth variant="contained"
                sx={{ mt:3, mb:2 }}>
                modify
                </Button>

            </form>
            </section>
        </React.Fragment>
    )
}

export default MemberDataUpdate