package H.tradingPlatform.domain.member.dto;

import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Data
public class JoinRequestDto {

    @NotBlank(message = "아이디는 필수 입니다.")
    @Length(min = 5,max = 20,message = "아이디는 5~20자 입니다.")
    private String loginId;

    @NotBlank(message = "비밀번호는 필수 입니다.")
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,20}",
           message = "비밀번호는 영문 대 소문자, 숫자, 특수문자($@$!%*?&)를 사용하세요. 비밀번호는 8~20자 입니다.")
    private String password;

    @NotNull(message = "잘못된 형식이거나 입력하지 않았습니다.")
    @Range(min = 0000000,max =9999999, message = "학번은 7자 입니다.")
    private int studentId;

    @NotBlank(message = "이름은 필수 입니다.")
    private String name;

    @NotBlank(message = "성별은 필수 입니다.")
    private String gender;

    @NotBlank(message = "이메일은 필수 입니다.")
    @Pattern(regexp = "^[A-Za-z0-9._%+-]+@hansung.ac.kr$",
            message = "잘못된 형식입니다. ex) hansung@hansung.ac.kr")
    private String email;

    @NotBlank(message = "생년월일은 필수 입니다.")
    @Length(min = 6,max = 6,message = "잘못된 형식입니다. ex) YYMMDD")
    private String birthDate;
}
