import React, { useState, useEffect } from "react";
import Button from '@mui/material/Button';
import axios from "axios";
import {Box} from '@mui/material/';
import getCookie from '../hooks/getCookie';
import './commentCss/PostComment.css';
import Star from "../components/Star";
import { useLocation } from 'react-router-dom';


let SERVER_URL = require("../test");

//기부자 평가 페이지
const PostComment = () => {

  const [clicked1, setClicked1] = useState(0);
  const [clicked2, setClicked2] = useState(0);
  const [clicked3, setClicked3] = useState(0);
  const createArray = [1,2,3,4,5]

  const [data, setData] = useState("");
  const onChange = (e) => {
    setData(e.target.value)
  }
  const location = useLocation();
  const postId = location.state.postId;

  let datadto = new Object();
  datadto.comment = data;
  datadto.postId = postId;
  datadto.attitudePoint = clicked1;
  datadto.beneficialPoint = clicked2;
  datadto.professionalPoint = clicked3;

  const onClick = () => {
    sendReviewhandler();
  }
  const sendReviewhandler = async () => {

    await axios.post(SERVER_URL.test()+'evaluation', datadto, { headers: { Authorization: `Bearer${getCookie('id')}` }})
        .then((response) => {
          if(response.data.status === 201) {
            alert(response.data.data.message);
            document.location.href = '/';
          }
          else if (response.data.status === 403) {
            alert(response.data.data.message);
            document.location.href = '/';
          }
        })
  }

  return (
      <React.Fragment>
        <Box>
          <form>
            <section>
              <div className="title centered text-4xl pt-80" > 재능기부자를 평가해주세요! </div>
            </section>
            <section>

              <div className="container">
                <div className="attitude pr-20">
                  <div className="text-xl pt-8"> [ 태도 ] </div>
                  <div className="atti">

                  {createArray.map((n,i) =>
                  <Star key={i} selected={clicked1>i} onSelect={() => setClicked1(i+1)}/>)}

                    </div>
                </div>
                <div className="beneficial pr-20">
                  <div className="text-xl pt-8">[ 유익성 ] </div>
                  <div className="atti">
                  {createArray.map((n,i) =>
                      <Star key={i} selected={clicked2>i} onSelect={() => setClicked2(i+1)}/>)}
                </div>
                </div>
                <div className="professional pr-23">
                  <div className="text-xl pt-8"> [ 전문성 ]</div>
                  <div className="atti">
                  {createArray.map((n,i) =>
                      <Star key={i} selected={clicked3>i} onSelect={() => setClicked3(i+1)}/>)}
                  </div>
              </div>
              </div>
            </section>
            <section>

              <p className="center">
            <textarea className="container" //코멘트 작성 창

                      placeholder="Write a comment here!"
                      style={styles.textarea}
                      type="comment"
                      id = "comment"
                      name="comment"
                      data={data}
                      onChange={onChange}


            />
              </p>

              <div className="button"> {/* 작성완료버튼 */}
                <Button variant="contained" color="success" onClick={onClick}>
                  {/* onclick={sendReviewhandler} */}
                  작성 완료
                </Button>
              </div>
            </section>
          </form>
        </Box>
      </React.Fragment>
  )

} //postComment 끝!

export default PostComment

const styles = {
  textarea: {
    border: "1px solid #a9a9a9",
    borderRadius: 5,
    padding: 10,
    margin: "50px 70px",
    minHeight: 100,
    width: 1000
  }
}

