package H.tradingPlatform.domain.image.repository;

import H.tradingPlatform.domain.image.Image;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;

@Repository
@RequiredArgsConstructor
public class ImageRepository {

    private final EntityManager em;

    public Long saveImage(Image image){
        em.persist(image);
        return image.getImageId();
    }
}
