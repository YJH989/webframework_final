package H.tradingPlatform.domain.member.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class JoinMemberDto {

    private Long id;
    private String message;
}
